# 02 — Instalação Manual (passo a passo humano)

> **Tempo estimado:** 30-60 minutos.
> **Pré-requisitos:** VPS limpa Debian 11+/Ubuntu 22.04+, root SSH, IP público, domínio com DNS gerenciado.

---

## 1. Preparar VPS

Login como root via SSH:

```bash
ssh root@<IP_DA_VPS>
```

Atualizar:

```bash
apt-get update && apt-get upgrade -y
```

---

## 2. Instalar Node.js 20 (via nvm)

```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
source ~/.bashrc
nvm install 20
nvm use 20
nvm alias default 20

# Verifica
node --version    # esperado: v20.x.x
npm --version
```

---

## 3. Instalar Claude Code

```bash
npm install -g @anthropic-ai/claude-code
claude --version
```

Faça login na conta Anthropic na primeira execução (`claude` interativo) ou exporte `ANTHROPIC_API_KEY` no shell.

---

## 4. Clonar/copiar o Saga para `/opt/saga`

**Opção A — clonar de repositório:**
```bash
git clone <URL_DO_REPO> /opt/saga
cd /opt/saga
```

**Opção B — extrair tarball de uma instalação existente:**
```bash
mkdir -p /opt/saga
tar -xzf saga.tar.gz -C /opt/saga --strip-components=1
cd /opt/saga
```

**Opção C — bootstrap zero** (estrutura mínima já incluída em `scripts/bootstrap.sh`):
```bash
mkdir -p /opt/saga
cd /opt/saga
# Copiar manualmente: src/, scripts/, package.json, ecosystem.config.js, CLAUDE.md
```

---

## 5. Rodar bootstrap.sh (ambiente nativo)

```bash
cd /opt/saga
chmod +x scripts/bootstrap.sh
sudo bash scripts/bootstrap.sh
```

O bootstrap (idempotente) faz:

| Passo | O que faz |
|-------|-----------|
| 0.B | Derruba qualquer stack Docker remanescente (se houver) |
| 0.C | Purga pacotes Docker (se houver) |
| 0.D | Cria swap de 4 GB e ajusta `vm.swappiness=10` |
| 0.E | Instala Chromium + libs Puppeteer + sqlite3 + certbot + PM2 + pm2-logrotate |
| 0.F | Instala Nginx, gera site para `<SEU_DOMINIO>`, emite cert Let's Encrypt |
| 0.G | Cria estrutura `/opt/saga/{src,config,data,logs,scripts}` |

> **Importante:** o `bootstrap.sh` original tem o domínio e email hardcoded. Antes de rodar, edite as duas primeiras variáveis:
>
> ```bash
> DOMAIN="<SEU_DOMINIO>"
> EMAIL="<SEU_EMAIL>"
> ```

> **Alternativa NPM (Nginx Proxy Manager via Docker):** se preferir gerenciar SSL via NPM em vez de Nginx + Certbot direto, **pule o passo 0.F** e configure NPM separadamente apontando para `127.0.0.1:3002`. Detalhes em `09-integracoes-externas.md`.

---

## 6. Instalar dependências Node

```bash
cd /opt/saga
npm install --production
```

Tempo: 3-5 min. Vai compilar `better-sqlite3` nativamente (precisa de `build-essential`, instalado no bootstrap).

---

## 7. Configurar `.env`

Crie o arquivo `.env` na raiz:

```bash
cp .env.example .env  # se houver .env.example, senão crie do zero
nano .env
```

Conteúdo mínimo (substitua placeholders):

```bash
NODE_ENV=production
PORT=3002
HOST=127.0.0.1
LOG_LEVEL=info

DB_PATH=./data/worker.db
AUTH_PATH=./data/.wwebjs_auth
MEDIA_PATH=./data/media
CHROMIUM_PATH=/usr/bin/chromium
CLIENT_ID=saga

# Tokens locais (gere com openssl rand -hex 32)
API_TOKEN=<32_CHARS_OR_MORE>
JWT_SECRET=<32_CHARS_OR_MORE>
ADMIN_USER=admin
ADMIN_PASSWORD_HASH=<BCRYPT_HASH>  # gerar com: npm run hash-password -- 'sua_senha'
JWT_TTL_DAYS=7

# Whitelist do agente (telefones com 9 últimos dígitos extraídos automaticamente)
AGENT_WHITELIST=<SEU_TELEFONE_E164>

# LLM e transcrição
ANTHROPIC_API_KEY=<COLE_AQUI>
GROQ_API_KEY=<COLE_AQUI_OPCIONAL>

# Webhook outbound (opcional)
WEBHOOK_URL=
WEBHOOK_TOKEN=

# Tunables
SEND_MIN_DELAY_MS=3000
SEND_MAX_DELAY_MS=7000
SEND_BURST_LIMIT=30
SEND_BURST_WINDOW_MS=300000
TYPING_PER_CHAR_MS=30
TYPING_MAX_MS=10000
AUTH_WATCHDOG_MS=120000
RECONNECT_BASE_MS=5000
RECONNECT_MAX_MS=120000

# TTS
TTS_VOICE=pt-BR-AntonioNeural
TTS_RATE=+0%
TTS_PITCH=+0Hz
```

**Como gerar cada token:**
- `API_TOKEN` e `JWT_SECRET`: `openssl rand -hex 32`
- `ADMIN_PASSWORD_HASH`:
  ```bash
  npm run hash-password -- 'sua_senha_aqui'
  # Cola a saída em ADMIN_PASSWORD_HASH=
  ```

Detalhes de cada credencial e como obter em `03-credenciais-e-tokens.md`.

Permissões:
```bash
chmod 600 .env
```

---

## 8. Rodar migrations

```bash
cd /opt/saga
npm run migrate
```

Esperado: aplica `001_initial.sql` até `011_sessoes_outlier.sql` (ou todas as que existirem em `src/db/migrations/`). Cria `data/worker.db`.

Conferir:
```bash
sqlite3 data/worker.db ".tables"
# Esperado: messages, chats, contacts, send_queue, webhooks, app_settings, etc.
```

---

## 9. Configurar Nginx (proxy HTTP → 127.0.0.1:3002)

O bootstrap já criou um stub em `/etc/nginx/sites-available/<SEU_DOMINIO>.conf`. Substitua o `location /` para fazer proxy para o worker:

```bash
sudo nano /etc/nginx/sites-available/<SEU_DOMINIO>.conf
```

Conteúdo (substitua `<SEU_DOMINIO>`):

```nginx
server {
    listen 80;
    listen [::]:80;
    server_name <SEU_DOMINIO>;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name <SEU_DOMINIO>;

    ssl_certificate     /etc/letsencrypt/live/<SEU_DOMINIO>/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/<SEU_DOMINIO>/privkey.pem;

    client_max_body_size 25M;

    location / {
        proxy_pass http://127.0.0.1:3002;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 90s;
    }
}
```

Validar e recarregar:
```bash
nginx -t && systemctl reload nginx
```

Para limites adicionais (rate limit), use `config/nginx-limits.conf` incluído no projeto.

---

## 10. Subir via PM2

```bash
cd /opt/saga
pm2 start ecosystem.config.js
pm2 save
pm2 startup systemd
# Copie e cole o comando que o PM2 imprimir (geralmente um sudo ...)
```

Conferir:
```bash
pm2 status
# Deve mostrar: saga (online) e saga-runner (online)

pm2 logs saga --lines 50
# Deve aparecer: "HTTP listening" na porta 3002 e início do init wweb.js
```

---

## 11. Parear o número WhatsApp

Você tem duas opções:

### Opção A — pairing code (recomendado, sem QR)

```bash
curl -s "http://127.0.0.1:3002/qr?phone=<SEU_TELEFONE_E164>" \
  -H "Authorization: Bearer $(grep ^API_TOKEN /opt/saga/.env | cut -d= -f2)" | jq
```

Use o `pairingCode` retornado: no celular abra WhatsApp → Configurações → Aparelhos conectados → Conectar um aparelho → Conectar com número de telefone → digite o código.

### Opção B — QR code (acessar painel)

Abra `https://<SEU_DOMINIO>/login`, faça login com `admin` e a senha que você setou. Vá em "Status" e escaneie o QR no celular (mesma rota: WhatsApp → Aparelhos conectados → Conectar).

---

## 12. Validar fim-a-fim

Mande uma mensagem do seu celular pessoal (que está na whitelist) para o número conectado:

```
oi, teste 1
```

Em ~10s o agente deve responder. Acompanhe:

```bash
pm2 logs saga-runner --lines 100
# Deve aparecer: "X pending msg(s) detected, debouncing..."
# Em seguida: "spawning claude -p"
# E depois: "claude -p finished exit=0"
```

Se chegou resposta, **fim**. Sistema instalado e funcionando.

---

## 13. Configurações pós-instalação (opcionais)

### Backup automático
Adicione ao crontab:
```bash
crontab -e
```
```cron
0 3 * * * /opt/saga/scripts/backup.sh >> /opt/saga/logs/backup.log 2>&1
```

### Cobrança automática de follow-ups
```cron
0 12 * * * /opt/saga/scripts/daily-chase.sh >> /opt/saga/logs/daily-chase.log 2>&1
```

### Fail2ban
```bash
sudo cp /opt/saga/config/fail2ban-jail.conf /etc/fail2ban/jail.d/saga.conf
sudo cp /opt/saga/config/fail2ban-wwworker.conf /etc/fail2ban/filter.d/saga.conf
sudo systemctl restart fail2ban
```

### Liberar Fase 2 (auto-resposta para não-whitelist)
Por padrão `api_replies_panic=1` (silenciado). Para ativar:
```bash
sqlite3 /opt/saga/data/worker.db \
  "UPDATE app_settings SET value='0', updated_at=datetime('now') WHERE key='api_replies_panic';"
```
Recomenda-se **não** liberar até ter certeza que o agente está calibrado.

---

## 14. Treinar o agente (próximo passo após instalação)

A instalação termina com o sistema técnico funcionando, mas o agente é "cru". Veja `06-treinamento-do-sistema.md` para o método de treinamento que transforma o agente em um operador realmente útil.

Resumo: comece mandando comandos simples por DM, vá ensinando preferências de tom, contatos da equipe, regras de negócio. Cada `"lembra disso"` ou `"salva esse contato"` vira memória persistente.
