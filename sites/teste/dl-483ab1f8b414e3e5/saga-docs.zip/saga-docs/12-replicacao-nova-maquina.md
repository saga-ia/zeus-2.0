# 12 — Replicação em Nova Máquina (guia completo da réplica zero)

> Este capítulo é o **passo-a-passo definitivo** para criar um Saga novo, do zero, em outra VPS. Combina partes de `02-instalacao-manual.md` + `03-credenciais-e-tokens.md` + `06-treinamento-do-sistema.md` em um fluxo único e linear.
>
> **Tempo total esperado:** 90 a 180 minutos (60% disso é espera de download + parear WhatsApp + treinamento inicial).

---

## Antes de começar — o que você precisa em mãos

### Recursos de infra
- [ ] VPS Debian 11+/Ubuntu 22.04+ com root SSH (4 GB RAM mínimo, 40 GB disco)
- [ ] IP público fixo da VPS
- [ ] Domínio próprio com DNS gerenciado (Cloudflare recomendado, mas qualquer provedor com API funciona)
- [ ] Email para Let's Encrypt
- [ ] Acesso ao DNS para criar subdomínio principal (ex.: `saga.<seu-dominio>`)

### Credenciais a separar antes
- [ ] Token API **Anthropic** (`sk-ant-api03-...`) — console.anthropic.com
- [ ] Token API **Cloudflare** + Account ID — dash.cloudflare.com
- [ ] Token **Groq** (`gsk_...`) — opcional, console.groq.com
- [ ] Tokens **Google OAuth** (Client ID + Secret) — opcional, console.cloud.google.com
- [ ] Tokens **Meta Graph API** (User token + System token) — opcional
- [ ] Token **Asaas** — opcional
- [ ] Senha admin que você vai usar no painel (escolha agora, vai ser hasheada)
- [ ] Telefone WhatsApp seu (vai ser whitelist) — formato E.164 sem `+`

### Cópia da instalação atual (se for migração, não nova instalação)
Se você está **clonando** um Saga existente para uma nova VPS, leve junto:
- [ ] Tarball do código (`tar -czf saga-source.tar.gz -C /opt/saga --exclude=node_modules --exclude=data/.wwebjs_auth --exclude=data/media .`)
- [ ] Backup do `worker.db` (`scripts/backup.sh` mais recente)
- [ ] Memórias do agente (`tar -czf memorias.tar.gz -C ~/.claude/projects -opt-saga/memory`)

---

## Passo 1 — Provisionar VPS e DNS (10 min)

### 1.1 Criar VPS
Provedor à escolha (Hetzner, DigitalOcean, Linode, Contabo, Hostinger). Imagem Debian 12 ou Ubuntu 24.04 LTS.

Após criação, anote o IP público.

### 1.2 Criar DNS
No seu provedor de DNS, crie um A record:
```
saga.<SEU_DOMINIO>  →  A  →  <IP_DA_VPS>
```

(Substitua `saga` pelo subdomínio que quiser. O nome principal do sistema é flexível.)

Aguarde propagação (1-5 min em Cloudflare, até 30 min em outros).

Verifique:
```bash
dig +short saga.<SEU_DOMINIO>
# Deve retornar o IP da VPS
```

---

## Passo 2 — Acesso e atualização inicial (5 min)

```bash
ssh root@<IP_DA_VPS>
apt-get update && apt-get upgrade -y
apt-get install -y curl wget git nano htop tmux build-essential
```

Configurar fuso horário (opcional mas recomendado):
```bash
timedatectl set-timezone America/Sao_Paulo  # ou seu fuso
```

Hostname (opcional):
```bash
hostnamectl set-hostname saga-prod
```

---

## Passo 3 — Instalar Node.js 20 + Claude Code (10 min)

### 3.1 Node via nvm
```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
source ~/.bashrc
nvm install 20
nvm use 20
nvm alias default 20

node --version  # v20.x.x
npm --version
```

### 3.2 Claude Code
```bash
npm install -g @anthropic-ai/claude-code
claude --version
```

### 3.3 Login no Claude Code
```bash
claude
# Vai abrir tela de login. Escolha "API key" ou "Login com Anthropic" conforme sua conta.
# Após login, sai (`exit` ou `/exit`).
```

Token fica salvo em `~/.claude/.credentials.json`.

---

## Passo 4 — Trazer/clonar o código do Saga (5-15 min)

### Opção A — Clonar de repositório
```bash
git clone <URL_DO_REPO_SAGA> /opt/saga
cd /opt/saga
```

### Opção B — Extrair de tarball (migração)
```bash
mkdir -p /opt/saga
# Subir o tarball para a VPS via scp:
# (no seu desktop) scp saga-source.tar.gz root@<IP>:/tmp/
tar -xzf /tmp/saga-source.tar.gz -C /opt/saga
cd /opt/saga
```

### Opção C — Bootstrap zero
Se não tem nem repo nem tarball, precisa criar a estrutura mínima do worker manualmente — ou use a documentação como guia para reconstruir cada arquivo. Não recomendado para primeira tentativa.

Estrutura esperada:
```bash
ls /opt/saga
# Esperado: src/ scripts/ config/ public/ ecosystem.config.js package.json CLAUDE.md
```

---

## Passo 5 — Bootstrap do ambiente nativo (5-15 min)

### 5.1 Editar variáveis no `bootstrap.sh`
```bash
nano /opt/saga/scripts/bootstrap.sh
# Mude as primeiras linhas:
#   DOMAIN="saga.<SEU_DOMINIO>"
#   EMAIL="<SEU_EMAIL>"
```

### 5.2 Rodar bootstrap
```bash
chmod +x /opt/saga/scripts/bootstrap.sh
sudo bash /opt/saga/scripts/bootstrap.sh
```

Você vai ver o progresso por fase (0.B, 0.C, 0.D, 0.E, 0.F, 0.G). Demora pelo `apt install` do Chromium e libs do Puppeteer.

Ao final:
- Swap de 4 GB criado
- Chromium + libs Puppeteer instalados
- PM2 + pm2-logrotate instalados
- Nginx com TLS Let's Encrypt para `saga.<SEU_DOMINIO>` ativo
- Estrutura `/opt/saga/{src,config,data,logs,scripts}` criada

---

## Passo 6 — Instalar dependências Node (3-5 min)

```bash
cd /opt/saga
npm install --production
```

Vai compilar `better-sqlite3` localmente (precisa do `build-essential` do bootstrap). Se der erro, conferir que `python3` e `make` estão disponíveis.

---

## Passo 7 — Configurar `.env` (10 min)

### 7.1 Gerar segredos locais
```bash
echo "API_TOKEN=$(openssl rand -hex 32)"
echo "JWT_SECRET=$(openssl rand -hex 32)"
```
Copie a saída para um lugar seguro.

### 7.2 Hashear senha admin
```bash
cd /opt/saga
npm run hash-password -- '<SUA_SENHA_AQUI>'
# Saída: $2a$10$...
```

### 7.3 Criar `.env`
```bash
nano /opt/saga/.env
```

Conteúdo:
```bash
NODE_ENV=production
PORT=3002
HOST=127.0.0.1
LOG_LEVEL=info

DB_PATH=./data/worker.db
AUTH_PATH=./data/.wwebjs_auth
MEDIA_PATH=./data/media
CHROMIUM_PATH=/usr/bin/chromium
CLIENT_ID=saga

# Geramos no passo 7.1
API_TOKEN=<COLE_AQUI>
JWT_SECRET=<COLE_AQUI>
ADMIN_USER=admin
ADMIN_PASSWORD_HASH=<COLE_HASH_DO_PASSO_7.2>
JWT_TTL_DAYS=7

# Telefone que vai operar o agente (whitelist)
AGENT_WHITELIST=<SEU_TELEFONE_E164>

# LLMs
ANTHROPIC_API_KEY=<COLE_TOKEN_ANTHROPIC>
GROQ_API_KEY=<COLE_TOKEN_GROQ_OU_DEIXE_VAZIO>

# Webhook (opcional, deixe vazio se não tem)
WEBHOOK_URL=
WEBHOOK_TOKEN=

# Tunables (defaults razoáveis)
SEND_MIN_DELAY_MS=3000
SEND_MAX_DELAY_MS=7000
SEND_BURST_LIMIT=30
SEND_BURST_WINDOW_MS=300000
TYPING_PER_CHAR_MS=30
TYPING_MAX_MS=10000
AUTH_WATCHDOG_MS=120000
RECONNECT_BASE_MS=5000
RECONNECT_MAX_MS=120000

# TTS
TTS_VOICE=pt-BR-AntonioNeural
TTS_RATE=+0%
TTS_PITCH=+0Hz
```

```bash
chmod 600 /opt/saga/.env
```

---

## Passo 8 — Migrations (1 min)

```bash
cd /opt/saga
npm run migrate
```

Verificar:
```bash
sqlite3 /opt/saga/data/worker.db ".tables"
# Deve listar: messages, chats, contacts, send_queue, app_settings, contact_settings, ...
```

### 8.1 Restore do DB existente (só em migração)
Se você está clonando uma instalação:
```bash
# Para qualquer processo que esteja segurando o lock
rm /opt/saga/data/worker.db
gunzip -c /tmp/worker.db.gz > /opt/saga/data/worker.db
chmod 644 /opt/saga/data/worker.db
```

---

## Passo 9 — Configurar tokens dinâmicos no SQLite (5 min)

Tokens que **não** ficam no `.env` e sim no banco:

```bash
sqlite3 /opt/saga/data/worker.db <<SQL
-- Cloudflare
INSERT OR REPLACE INTO app_settings (key, value, updated_at) VALUES
  ('cloudflare_api_token', '<COLE_TOKEN_CLOUDFLARE>', datetime('now')),
  ('cloudflare_account_id', '<COLE_ACCOUNT_ID>', datetime('now'));

-- Meta Ads (opcional)
INSERT OR REPLACE INTO app_settings (key, value, updated_at) VALUES
  ('jeff_meta_user_token', '<COLE_USER_TOKEN_META>', datetime('now')),
  ('jeff_meta_system_token', '<COLE_SYSTEM_TOKEN_META>', datetime('now'));

-- Asaas (opcional)
INSERT OR REPLACE INTO app_settings (key, value, updated_at) VALUES
  ('asaas_api_token', '<COLE_TOKEN_ASAAS>', datetime('now'));

-- Google OAuth (opcional, vai precisar do fluxo de auth depois)
INSERT OR REPLACE INTO app_settings (key, value, updated_at) VALUES
  ('google_oauth_client_id', '<CLIENT_ID>.apps.googleusercontent.com', datetime('now')),
  ('google_oauth_client_secret', '<CLIENT_SECRET>', datetime('now'));
SQL
```

---

## Passo 10 — Subir via PM2 (2 min)

```bash
cd /opt/saga
pm2 start ecosystem.config.js
pm2 save
pm2 startup systemd
# Cole e execute o comando que o PM2 imprimir
```

Verificar:
```bash
pm2 status
# saga: online
# saga-runner: online
```

Ver logs do boot:
```bash
pm2 logs saga --lines 30
# Esperado: "HTTP listening on host: 127.0.0.1, port: 3002"
```

---

## Passo 11 — Configurar Nginx (5 min)

O bootstrap criou um stub. Substitua para fazer proxy:

```bash
sudo nano /etc/nginx/sites-available/saga.<SEU_DOMINIO>.conf
```

```nginx
server {
    listen 80;
    server_name saga.<SEU_DOMINIO>;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name saga.<SEU_DOMINIO>;

    ssl_certificate     /etc/letsencrypt/live/saga.<SEU_DOMINIO>/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/saga.<SEU_DOMINIO>/privkey.pem;

    client_max_body_size 25M;

    location / {
        proxy_pass http://127.0.0.1:3002;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 90s;
    }
}
```

```bash
nginx -t && systemctl reload nginx
```

Teste:
```bash
curl -s https://saga.<SEU_DOMINIO>/health
# {"status":"ok"}
```

---

## Passo 12 — Parear o WhatsApp (5-10 min)

### 12.1 Pegar pairing code
```bash
TOKEN=$(grep ^API_TOKEN /opt/saga/.env | cut -d= -f2)
curl -s "http://127.0.0.1:3002/qr?phone=<SEU_TELEFONE_E164>" \
  -H "Authorization: Bearer $TOKEN" | jq
```

Saída esperada:
```json
{
  "state": "qr",
  "pairingCode": "ABCD-EFGH"
}
```

### 12.2 Aplicar no WhatsApp
1. Abra WhatsApp no celular do número que vai conectar
2. Configurações → Aparelhos conectados → Conectar um aparelho → Conectar com número de telefone
3. Digite o `pairingCode` (sem o hífen)
4. Aceite o pareamento

### 12.3 Confirmar
```bash
sleep 30
curl -s http://127.0.0.1:3002/status \
  -H "Authorization: Bearer $TOKEN" | jq
# state: "ready", meNumber populado
```

---

## Passo 13 — Restaurar memórias do agente (5 min, só em migração)

```bash
mkdir -p ~/.claude/projects/-opt-saga/memory
cd ~/.claude/projects/-opt-saga
tar -xzf /tmp/memorias.tar.gz
ls memory/
# Deve listar MEMORY.md + arquivos *.md
```

Para instalação **nova** (sem cópia), pule este passo. As memórias vão nascer pela interação (ver `06-treinamento-do-sistema.md`).

---

## Passo 14 — Smoke test fim-a-fim (2 min)

Mande mensagem do seu celular (whitelist) para o número conectado:
```
oi, teste 1
```

Em 10-30s o agente deve responder. Acompanhe:
```bash
pm2 logs saga-runner --lines 50
# Deve aparecer:
#   "X pending msg(s) detected, debouncing..."
#   "spawning claude -p"
#   "claude -p finished exit=0"
```

Se chegou resposta → **réplica funcionando**.

---

## Passo 15 — Pós-instalação (15-30 min)

### 15.1 Backup automático
```bash
crontab -e
# Adicione:
0 3 * * * /opt/saga/scripts/backup.sh >> /opt/saga/logs/backup.log 2>&1
```

### 15.2 Daily chase (cobranças)
```cron
0 12 * * * /opt/saga/scripts/daily-chase.sh >> /opt/saga/logs/daily-chase.log 2>&1
```

### 15.3 Firewall
```bash
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw enable
```

### 15.4 Fail2ban (já instalado pelo bootstrap)
```bash
cp /opt/saga/config/fail2ban-jail.conf /etc/fail2ban/jail.d/saga.conf
cp /opt/saga/config/fail2ban-wwworker.conf /etc/fail2ban/filter.d/saga.conf
systemctl restart fail2ban
```

### 15.5 Liberação Fase 2 (auto-resposta)
**Pule este passo** se a réplica é nova e o agente ainda não foi treinado. Depois de 1-4 semanas treinando:
```bash
sqlite3 /opt/saga/data/worker.db \
  "UPDATE app_settings SET value='0' WHERE key='api_replies_panic';"
```

### 15.6 Renovação SSL automática
Já configurada pelo certbot. Confirme:
```bash
certbot renew --dry-run
```

---

## Passo 16 — Treinamento inicial (1-7 dias, contínuo)

A réplica está **tecnicamente** pronta. Mas o agente é "cru". Siga `06-treinamento-do-sistema.md` para o método de treinamento.

Mínimo recomendado nas primeiras 48h:
1. **Identidade.** "Seu nome é <NOME>. Salva."
2. **Tom.** "Comigo: <descrição do tom>. Salva."
3. **Contatos chave.** Pelo menos as 3-5 pessoas mais importantes da operação.
4. **Regras inquebráveis.** "Antes de mandar pra terceiro, sempre pergunta. Salva."
5. **Confidencialidade.** "Tudo que falamos aqui é segredo. Salva."

Após 7 dias, o agente deve estar respondendo de forma consistente. Após 30 dias, deve estar antecipando pedidos.

---

## Checklist final

- [ ] PM2 `saga` e `saga-runner` online
- [ ] `/health` retorna 200
- [ ] `/status` retorna `state=ready` com `meNumber` populado
- [ ] Você manda WhatsApp e o agente responde
- [ ] Backup automático no cron
- [ ] Fail2ban ativo
- [ ] UFW com regras corretas
- [ ] Let's Encrypt renovação automática verificada
- [ ] (Migração) memórias restauradas e testadas
- [ ] (Nova) treinamento inicial iniciado conforme cap. 06

---

## Diferenças entre nova instalação vs migração

| Aspecto | Nova | Migração |
|---|---|---|
| Código (`src/`) | Clone do repo | Tarball de origem |
| `.env` | Gerar do zero | Pode reaproveitar (com tokens novos onde precisar) |
| `worker.db` | Migrations criam vazio | Restaurar backup |
| Sessão WhatsApp | Parear pela primeira vez | Re-parear (sessão antiga não migra) |
| Memórias | Vazio (treinar do zero) | Restaurar tarball |
| Cron jobs | Criar novos | Recriar |
| Domínio + SSL | Configurar do zero | Configurar do zero |

A sessão WhatsApp **não é portável** entre máquinas — você precisa re-parear sempre. Isso é por design do whatsapp-web.js (segurança).

---

## Troubleshooting de réplica

Os problemas mais comuns ao replicar:

| Problema | Onde olhar |
|---|---|
| `npm install` falhou no `better-sqlite3` | Verificar `build-essential` instalado, Python disponível |
| `pm2 start` reinicia em loop | `pm2 logs saga` para ver stack — geralmente `.env` faltando algo |
| Pareamento WhatsApp não fecha | Conferir 12.3 do `02-instalacao-manual.md`, ver `11-troubleshooting.md` #14 |
| Agente não responde mesmo após pareamento | Conferir `AGENT_WHITELIST` no `.env` casa com seu telefone (somente últimos 9 dígitos importam) |
| Erro `chromium not found` | Ajustar `CHROMIUM_PATH` no `.env`, ou reinstalar via `apt install chromium` |
| SSL não emite | DNS ainda não propagou, ou porta 80 bloqueada — `nslookup`, `curl http://saga.<DOMINIO>` |

Para qualquer outro problema, ver `11-troubleshooting.md`.
