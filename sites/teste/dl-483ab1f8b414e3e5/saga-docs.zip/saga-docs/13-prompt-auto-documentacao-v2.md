# 13 — Prompt de Auto-Documentação v2.0

> Esta documentação foi gerada usando uma versão adaptada do **PROMPT DE AUTO-DOCUMENTAÇÃO AUTÔNOMA v2.0**. Este capítulo guarda o prompt original e ensina como reusá-lo no futuro para regenerar/atualizar a doc.

---

## Para que serve

O prompt é uma **instrução para Claude Code** que automatiza o processo de criar/atualizar a documentação completa de uma instalação Saga.

**Casos de uso:**
1. **Reaplicar em outra cópia.** Se você instalar um Saga em outra VPS, pode rodar este prompt naquela VPS para gerar a doc específica daquela instalação.
2. **Atualizar a doc após mudanças grandes.** Refatoraram o sistema, adicionaram migrations, mudaram integrações? Rode o prompt e ele regenera a doc com o estado atual.
3. **Auto-documentação periódica.** Rotina trimestral: rode o prompt, compare com a doc anterior, identifique drift.

---

## Limitações

Este prompt:
- ✅ Documenta **estado atual** (Opção A — fiel ao que existe)
- ✅ Aplica substituições de nomes (sistema, paths, dono, equipe)
- ✅ Remove dados pessoais e tokens reais (substitui por placeholders)
- ❌ **Não** cria as estruturas que não existem (skills, agents, commands) — descreve a ausência
- ❌ **Não** treina o agente — só documenta o que já está treinado

---

## Como usar (versão simplificada)

1. Abra Claude Code numa sessão limpa **na VPS onde o Saga está instalado**:
   ```bash
   cd /opt/saga
   claude
   ```

2. Cole o prompt abaixo (copie da seção "Prompt completo" e cole na conversa).

3. Responda as perguntas iniciais quando o agente pedir:
   - Nome do sistema (Saga, ou outro)
   - Caminho de instalação (`/opt/saga`)
   - Nomes PM2 (saga, saga-runner)
   - Dono/criador
   - Pessoas a remover do doc
   - Domínio (placeholder ou hardcoded)
   - Telefone na whitelist (apenas o seu)

4. Confirme antes que ele inicie a geração.

5. Aguarde (~30-60 min). O agente vai:
   - Ler o sistema completo
   - Aplicar substituições
   - Gerar 14 arquivos `.md` em `./docs/` (ou no caminho que você indicar)
   - Reportar pendências (`<<DEFINIR: ...>>`) ao final

---

## Prompt completo (copie a partir daqui)

```
🧠 PROMPT DE AUTO-DOCUMENTAÇÃO AUTÔNOMA — AGENTE CLAUDE CODE
Versão: 2.0.0 — Modo Adaptativo (faz perguntas-chave no início, depois autônomo)

═══════════════════════════════════════════════════════════════

Você é um Claude Code rodando numa VPS onde está instalado um sistema 
chamado Saga (worker WhatsApp + agente autônomo). Sua missão é gerar 
documentação completa do sistema em ./docs/, no diretório onde estou rodando.

REGRAS DE SAÍDA:
- Não modifique nenhum arquivo do sistema vivo
- Não reinicie nenhum processo
- Crie toda a saída em /root/saga-docs/ (ou pasta que o operador definir)
- Não invente comandos, paths, ou flags — leia o código antes
- Substitua tokens reais por <PLACEHOLDER>
- Substitua dados pessoais (CNPJ, telefones, nomes de família, contatos 
  de clientes) por descrições genéricas ou placeholders

REGRAS DE CONTEÚDO:
- Documente o ESTADO ATUAL exato (não estado ideal nem futuro)
- Se algo está vazio (ex.: pasta agents/), documente como "atualmente vazio"
- Não invente skills/agents/commands se não existirem
- Inclua detalhes operacionais reais (PM2 names, paths, portas, scripts)
- Capture decisões arquiteturais com o "porquê", não só o "o quê"

PERGUNTAS INICIAIS (faça TODAS antes de começar a gerar):
1. Caminho da instalação atual (default: /opt/saga)
2. Nome novo do sistema (default: Saga)
3. Caminho que o doc deve sugerir para a próxima cópia (default: /opt/saga)
4. Nomes PM2 atuais (default: whatsapp-worker, agent-runner)
5. Nomes PM2 que o doc deve usar para a próxima cópia 
   (default: saga, saga-runner)
6. Dono/criador (nome a usar no doc)
7. Pessoas a REMOVER do doc (nomes que aparecem no código/CLAUDE.md mas 
   não devem entrar no doc)
8. Domínio: usar como placeholder <SEU_DOMINIO> ou hardcoded?
9. Whitelist de telefones: hardcoded ou placeholder?
10. Caminho de saída do doc (default: ./docs/)

ANTES DE GERAR, mostre um RESUMO das decisões e peça confirmação 
explícita do operador.

ESTRUTURA DA DOCUMENTAÇÃO A GERAR (14 arquivos):
- README.md — entrada e índice
- 00-AUTO-INSTALL.md — prompt para Claude Code instalar o sistema 
  numa VPS limpa
- 01-arquitetura.md — visão geral, módulos, fluxo de dados
- 02-instalacao-manual.md — passo a passo humano
- 03-credenciais-e-tokens.md — cada token, onde obter, onde colar
- 04-worker-modulos.md — detalhamento de cada arquivo .js do worker
- 05-saga-runner.md (ou nome do daemon) — daemon do agente
- 06-treinamento-do-sistema.md — método de treinamento
- 07-criacao-de-memorias.md — estrutura técnica das memórias
- 08-skills-hooks-keybindings.md — estado atual + como personalizar
- 09-integracoes-externas.md — Google, Asaas, Cloudflare, Meta, etc.
- 10-operacao-diaria.md — runbook
- 11-troubleshooting.md — bugs conhecidos
- 12-replicacao-nova-maquina.md — guia da réplica zero
- 13-prompt-auto-documentacao-v2.md — este prompt + como reusar

LEITURA OBRIGATÓRIA ANTES DE GERAR:
- Todo o conteúdo de src/ do worker
- Scripts em scripts/ (especialmente agent-runner.sh, bootstrap.sh, 
  wapi.sh, cloudflare.sh, npm.sh, meta-ads.sh)
- Todos os arquivos em src/db/migrations/
- Conteúdo de package.json e ecosystem.config.js
- Conteúdo de CLAUDE.md do projeto
- ~/.claude/settings.json e settings.local.json
- Estrutura de ~/.claude/projects/<dir>/memory/ (sem ler conteúdo das 
  memórias se contiverem dados pessoais — só estrutura)

ACK OBRIGATÓRIO:
- Ack ao começar leitura
- Ack ao terminar leitura
- Ack a cada 2-3 arquivos .md gerados
- Ack final com lista de pendências (<<DEFINIR: ...>>) e relatório 
  de substituições aplicadas

PROIBIDO:
- Inventar
- Tocar arquivos do sistema vivo (incl. CLAUDE.md do worker)
- Reiniciar processos
- Vazar tokens reais ou dados pessoais

═══════════════════════════════════════════════════════════════

Após o operador aprovar o resumo, comece a leitura. Quando todos os 
14 arquivos estiverem gerados, reporte:
1. Quantos arquivos foram criados, em que caminho
2. Lista de placeholders que ficaram abertos (<<DEFINIR: ...>>)
3. Lista de substituições aplicadas
4. Avisos importantes (ex.: encontrou um token real em algum lugar 
   que precisou ser sanitizado)
```

---

## Como atualizar a doc no futuro

Conforme o sistema evolui, a doc fica desatualizada. Workflow recomendado:

### Trimestral (auto-update completo)
1. Rode o prompt v2.0 numa sessão Claude limpa
2. Salva a saída em `/root/saga-docs-novo/`
3. `diff -r /root/saga-docs/ /root/saga-docs-novo/` — vê o que mudou
4. Decide: aceita as mudanças? Faz `mv saga-docs-novo saga-docs` (ou cherry-pick)

### Pontual (mudança específica)
Para uma mudança isolada (ex.: adicionou nova migration), edite **só** o arquivo afetado:
```bash
cd /opt/saga
claude
> "lê src/db/migrations/012_*.sql e atualiza /root/saga-docs/04-worker-modulos.md 
   com a info dessa nova migration. Não toca em outros arquivos."
```

### Ao adicionar feature grande
Workflow ideal:
1. Implemente a feature (código)
2. Atualize `CLAUDE.md` do projeto se mudou comportamento do agente
3. Atualize 1-2 arquivos da doc relevantes (ex.: `01-arquitetura.md`, `04-worker-modulos.md`)
4. Rode `00-AUTO-INSTALL.md` mentalmente: ele ainda funcionaria numa VPS limpa? Se não, ajuste.

---

## Como evoluir o prompt v2.0

Quando o sistema mudar muito, o prompt fica desatualizado também (ex.: nova convenção de pastas, nova integração padrão). Use a versão atual como base e ajuste:

- Adicione novos arquivos à lista das 14 (vai virar 15+)
- Ajuste a lista de "leitura obrigatória" para incluir novos paths
- Ajuste perguntas iniciais se a renomeação tiver outras dimensões

Salve a versão nova como `v2.1`, `v3.0`, etc. e atualize esta seção.

---

## Comparação Opção A vs Opção B (referência histórica)

Quando esta documentação foi gerada, o operador escolheu **Opção A** (documentar estado atual fielmente, sem criar estruturas novas). A alternativa era **Opção B** (criar agents/skills/commands antes de documentar, para a próxima cópia já nascer "completa").

Se um dia for fazer Opção B numa réplica futura, o prompt acima precisa ser estendido com:

```
ANTES de documentar, crie no ~/.claude/:
- agents/<lista de agentes recomendados>
- skills/<lista de skills>
- commands/<lista de commands>
- CLAUDE.md global enxuto

E DEPOIS documente o estado já com essas estruturas.
```

Mas isso amplia o escopo do prompt para atuar **modificando** o setup, não só lendo. Cuidado: aprove com calma antes de virar autônomo nesse modo.

---

## Histórico de versões

| Versão | Data | Mudanças |
|---|---|---|
| 2.0.0 | (data da geração desta doc) | Versão inicial usada para gerar `/root/saga-docs/` |

Cada vez que rodar o prompt e modificá-lo, registre aqui a próxima versão.
