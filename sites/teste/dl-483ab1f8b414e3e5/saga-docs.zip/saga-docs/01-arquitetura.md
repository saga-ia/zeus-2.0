# 01 — Arquitetura do Sistema Saga

## Visão geral em uma frase

O Saga é um **agente operacional WhatsApp 24/7** composto por (a) um worker Node.js que conecta um número WhatsApp ao SQLite e expõe API HTTP, e (b) um daemon que dispara o Claude Code em modo headless toda vez que chega mensagem de quem está autorizado.

---

## Diagrama de blocos

```
                          ┌────────────────────────────────────────────────┐
                          │                  VPS Linux                     │
                          │                                                │
   ┌──────────┐  HTTPS    │   ┌───────────────────┐                        │
   │ WhatsApp │ <──────►  │   │  Nginx Proxy Mgr  │  <SEU_DOMINIO>:443     │
   │ (móvel)  │           │   │   (Docker, NPM)   │                        │
   └──────────┘           │   └─────────┬─────────┘                        │
                          │             │ proxy_pass                       │
   ┌──────────┐           │             ▼ http://127.0.0.1:3002            │
   │ Anthropic│ <──HTTP── │   ┌─────────────────────┐                      │
   │   API    │           │   │   PM2: saga         │                      │
   └──────────┘           │   │   (Express+wweb.js) │                      │
                          │   │                     │                      │
   ┌──────────┐           │   │   src/wa/client.js  │                      │
   │  Groq    │ <──HTTP── │   │   src/queue/        │                      │
   │ (Whisper)│           │   │   src/agent/        │                      │
   └──────────┘           │   │   src/routes/       │                      │
                          │   └────────┬────────────┘                      │
   ┌──────────┐           │            │                                   │
   │ Cloudflare│ <──HTTP─ │            ▼                                   │
   │  (DNS)   │           │     ┌─────────────┐                            │
   └──────────┘           │     │  worker.db  │  SQLite WAL                │
                          │     └─────┬───────┘                            │
   ┌──────────┐           │           │ poll                               │
   │ Meta     │ <──HTTP── │   ┌───────▼─────────────┐                      │
   │ Graph API│           │   │   PM2: saga-runner  │                      │
   └──────────┘           │   │   (bash, polls 5s)  │                      │
                          │   └───────┬─────────────┘                      │
   ┌──────────┐           │           │ spawn                              │
   │ Google   │ <──HTTP── │           ▼                                    │
   │  APIs    │           │   ┌─────────────────────┐                      │
   └──────────┘           │   │   claude -p (CLI)   │                      │
                          │   │ lê CLAUDE.md +      │                      │
   ┌──────────┐           │   │ memórias, executa   │                      │
   │  Asaas   │ <──HTTP── │   │ wapi.sh, sqlite3,   │                      │
   └──────────┘           │   │ scripts customs     │                      │
                          │   └─────────────────────┘                      │
                          └────────────────────────────────────────────────┘
```

---

## Os dois processos PM2

| Nome PM2 | Script | O que faz |
|----------|--------|-----------|
| `saga` | `node src/index.js` | Worker Node.js. Mantém sessão WhatsApp, recebe mensagens, persiste no SQLite, expõe API HTTP, dispara webhooks. **Sempre rodando**, reinicia automaticamente se cair. |
| `saga-runner` | `bash scripts/agent-runner.sh` | Loop que faz `SELECT COUNT(*) FROM messages WHERE processed_by_agent=0` a cada 5s. Quando detecta pendência, espera 8s de debounce, e dispara `claude -p` com o prompt padrão para processar a fila. |

Os dois ficam supervisionados pelo PM2 com `autorestart: true`.

---

## Estrutura de pastas (`/opt/saga/`)

```
/opt/saga/
├── CLAUDE.md                  # Instruções para o agente (lido pelo claude -p)
├── package.json
├── package-lock.json
├── ecosystem.config.js        # Config PM2 (saga + saga-runner)
├── .env                       # Tokens e segredos (não comitar)
├── config/
│   ├── nginx-site.conf        # Config Nginx legado (se usar Nginx direto)
│   ├── nginx-limits.conf
│   ├── fail2ban-jail.conf
│   └── fail2ban-wwworker.conf
├── data/
│   ├── worker.db              # SQLite WAL único do sistema
│   ├── .wwebjs_auth/          # Sessão whatsapp-web.js (gerada após pareamento)
│   ├── media/                 # Mídia recebida (imagens, PDFs, áudios)
│   │   └── tts/               # Áudios sintetizados pelo /agent/speak
│   └── archive/               # Arquivos arquivados manualmente
├── logs/
│   ├── out.log                # stdout do saga
│   ├── err.log                # stderr do saga
│   ├── agent-runner.out.log
│   ├── agent-runner.err.log
│   └── agent-runner.log       # log próprio do daemon
├── public/                    # Assets estáticos (painel admin, landings)
├── scripts/
│   ├── agent-runner.sh        # Daemon que dispara o agente
│   ├── bootstrap.sh           # Setup inicial idempotente
│   ├── backup.sh              # Backup do SQLite
│   ├── cloudflare.sh          # Helper API Cloudflare
│   ├── npm.sh                 # Helper Nginx Proxy Manager
│   ├── meta-ads.sh            # Helper Meta Graph API
│   ├── wapi.sh                # Wrapper da API HTTP do worker
│   └── daily-chase.sh         # Cron de cobrança automática de follow-ups
└── src/
    ├── index.js               # Bootstrap do processo
    ├── server.js              # Express app + routes
    ├── config.js              # Carrega .env e valida
    ├── logger.js              # pino logger
    ├── openapi.json           # Spec OpenAPI da API HTTP
    ├── auth/
    │   ├── middleware.js      # Bearer + JWT
    │   └── jwt.js             # Emissão/verificação de JWT
    ├── wa/                    # Cliente WhatsApp
    │   ├── client.js          # whatsapp-web.js + handlers
    │   ├── state.js           # Máquina de estados da sessão
    │   ├── watchdog.js        # Detecta cliente travado e força restart
    │   ├── typing.js          # Simulação de digitação
    │   ├── dedupe.js          # TimedSet para deduplicação
    │   └── contact-resolver.js # phone ↔ @c.us ↔ @lid
    ├── db/
    │   ├── index.js           # better-sqlite3 + abre conexão
    │   ├── migrations.js      # Aplica migrations no boot
    │   └── migrations/        # Arquivos SQL
    ├── queue/
    │   └── send-queue.js      # Fila anti-ban serializada
    ├── routes/
    │   ├── health.js
    │   ├── status.js
    │   ├── qr.js              # QR/pairing code
    │   ├── auth.js            # Login admin
    │   ├── messages.js        # GET/POST mensagens
    │   ├── send.js            # /send-message, /send-media, /send-audio
    │   ├── groups.js          # CRUD grupos
    │   ├── history.js         # Histórico
    │   ├── contacts.js        # Listar/checar contatos
    │   ├── webhooks.js        # CRUD webhooks
    │   ├── admin.js           # Stats, queue, panic, opt-out
    │   ├── session.js         # Logout, restart, marcar lido
    │   ├── agent.js           # /agent/speak (TTS)
    │   ├── inscricao.js       # Form público de inscrição
    │   └── static-html.js     # Landing pages estáticas
    ├── webhooks/
    │   └── outbound.js        # Disparador de webhooks
    ├── agent/
    │   ├── notify.js          # Helpers whitelist por phone
    │   ├── api-reply.js       # Resposta automática Anthropic (Fase 2)
    │   ├── mchat_poller.js    # Instagram comment-to-DM
    │   └── mchat_sheet.js
    ├── audio/
    │   ├── transcribe.js      # Groq Whisper
    │   └── tts.js             # Edge TTS
    ├── utils/
    │   ├── errors.js
    │   └── jid.js             # Normalização JIDs
    └── scripts/               # Scripts CLI (migrate, backup, etc.)
```

---

## Fluxo de mensagem (do recebimento ao reply)

```
[1] Usuário manda WhatsApp para o número conectado
       │
       ▼
[2] whatsapp-web.js (dentro do PM2 saga) recebe via Chromium
       │
       ▼
[3] src/wa/client.js handler:
    - Resolve phone canônico (5511...)
    - Se for áudio, baixa e chama Groq Whisper → transcription
    - Se for mídia, baixa para data/media/
    - INSERT em messages com processed_by_agent = ?
       │
       ▼
[4] Decisão de processed_by_agent:
    - Whitelist (Jefferson)?              → 0 (acordar agente)
    - Equipe autorizada via team_group?  → 0
    - Mensagem em grupo da equipe?       → 0
    - Mencionou o agente em qualquer grupo? → 0
    - Reply a mensagem do agente?        → 0
    - Caso contrário                     → 1 (não acionar agente)
       │
       ▼
[5] Worker dispara webhook outbound (se houver), insere no api_reply queue (Fase 2 se aplicável)
       │
       ▼
[6] saga-runner detecta processed_by_agent=0 no próximo poll (5s)
       │
       ▼
[7] Espera 8s de debounce (caso vier mais msg na sequência)
       │
       ▼
[8] Spawn: claude -p "<prompt padrão>" no diretório /opt/saga/
       │
       ▼
[9] Claude lê CLAUDE.md, lê memórias em ~/.claude/projects/.../memory/
    - Faz SELECT no SQLite das pendências do contato
    - Decide a resposta apropriada
    - Chama scripts/wapi.sh POST /send-message com a resposta
    - UPDATE messages SET processed_by_agent=1
       │
       ▼
[10] Worker (PM2 saga) processa o /send-message:
     - Enfileira em send_queue
     - Aplica typing simulation, rate limit (30/5min), delay 3-7s
     - Manda via wweb.js
     - INSERT em messages com direction='out', from_me=1
```

---

## Decisões arquiteturais importantes

### Por que SQLite e não Postgres/Redis?
Single tenant, workload de escrita/leitura modesto, sem replicação. SQLite WAL com better-sqlite3 dá > 50k ops/s no mesmo processo, é zero-config, e o backup é `cp worker.db`. Postgres/Redis seriam overhead injustificado.

### Por que `whatsapp-web.js` (não-oficial) e não a API oficial Meta?
A API oficial Meta tem custo por mensagem, exige aprovação de templates, restringe DMs e quebra a UX de chat livre. `whatsapp-web.js` usa o WhatsApp Web headless via Chromium — funciona como um celular real conectado. Trade-off: precisa parear (QR/pairing code) e a sessão pode expirar.

### Por que `claude -p` em vez de SDK direto?
O agente roda no mesmo ambiente onde o Jefferson opera o Claude Code interativamente. Compartilhar o `~/.claude/` significa:
- Memórias do agente (`projects/.../memory/`) são as mesmas em modo interativo e em modo daemon.
- Slash commands, skills, hooks, e settings.json são compartilhados.
- Quando o Jefferson treina o agente em DM ("salva isso"), o aprendizado vale também para o modo autônomo.

### Por que o `saga-runner` é em bash, não em Node?
- Bash é o menor denominador comum, sem dependência runtime.
- Trata `claude -p` como um subprocesso externo qualquer.
- `pgrep` para detectar concorrência com sessão interativa.
- Logs vão direto para arquivo, sem buffer de Node.

### Por que `contact_phone` e não `chat_id` para filtrar mensagens?
WhatsApp tem dois formatos de JID (`@c.us` legado e `@lid` novo) que flutuam dependendo do dispositivo do remetente e da migração da conta. O `chat_id` pode mudar do nada de `55XXXXXXXXXXX@c.us` para `<lid_opaco>@lid` para o mesmo contato. O `contact_phone` (só dígitos) é canônico e estável. **Sempre filtre por `contact_phone`**, use `chat_id` apenas para enviar.

### Por que o agente marca `processed_by_agent=1` no fim?
Sem essa marcação, o `saga-runner` re-dispara infinitamente para a mesma mensagem. Marcar "lido pelo agente" é o sinal de que pode parar de acionar. Por isso o passo 5 do ciclo no `CLAUDE.md` é obrigatório.

### Por que `from_me=1` é loop-safe?
Mensagens enviadas pelo próprio worker entram em `messages` também (com `direction='out'`, `from_me=1`). Se o agente fosse responder a mensagens com `from_me=1`, ele responderia às próprias respostas — loop infinito. A regra "**nunca responder a `from_me=1`**" no CLAUDE.md previne isso.

---

## Concorrência: o bug `state=ready` com `client null`

**Sintoma observado:** após restart do PM2, o endpoint `/status` retorna `state: 'ready'` mas o `client` interno está `null`, então qualquer envio falha silenciosamente.

**Causa:** a máquina de estados em `src/wa/state.js` marca `ready` quando o evento `client.on('ready')` dispara, mas se um restart acontece no meio do init, o cliente pode ficar referência stale.

**Mitigação atual:** o watchdog (`src/wa/watchdog.js`) detecta inatividade e força reinit. Para garantia, ao operar o agente sempre cheque `meNumber` no `/status` — se vier `null`, o cliente está zumbi e precisa de `pm2 restart saga`.

Detalhes em `11-troubleshooting.md`.

---

## Camadas de autorização

```
┌─────────────────────────────────────────────────────────────┐
│ Tier 1 — Whitelist (.env AGENT_WHITELIST)                   │
│   • Jefferson Henrike (dono)                                │
│   • Hard-block reativo: editar .env                         │
│   • Acorda o agente automaticamente                         │
│   • Pode pedir qualquer coisa, inclusive ações destrutivas  │
└─────────────────────────────────────────────────────────────┘
┌─────────────────────────────────────────────────────────────┐
│ Tier 2 — Team-authorized (contact_settings ou team_group)   │
│   • Quem entra no internal_team_group_jid vira team-auth    │
│   • Acorda o agente, mas com tom mais formal                │
│   • Não pode pedir ações destrutivas sem confirmação Tier 1 │
└─────────────────────────────────────────────────────────────┘
┌─────────────────────────────────────────────────────────────┐
│ Tier 3 — Não-whitelist                                      │
│   • Vai para Fase 2 (auto-resposta via API Anthropic)       │
│   • Modelo padrão: claude-sonnet-4-6                        │
│   • Controlado pelo botão de pânico (api_replies_panic)     │
│   • Pode ser silenciado individualmente (contact_settings)  │
└─────────────────────────────────────────────────────────────┘
```

Detalhes operacionais em `10-operacao-diaria.md`.

---

## Pontos de extensão

| Adicionar | Onde mexer |
|-----------|------------|
| Novo endpoint HTTP | `src/routes/<nome>.js` + registrar em `src/server.js` |
| Nova tabela | Criar `src/db/migrations/0XX_*.sql` (numerada sequencialmente) |
| Novo evento webhook | Disparar via `outbound.emit(eventName, payload)` em `src/wa/client.js` |
| Nova skill do agente | Adicionar bloco de instruções no `CLAUDE.md` raiz |
| Novo helper script | Criar em `scripts/<nome>.sh`, dar permissão de execução |
| Nova integração externa | Criar módulo em `src/agent/<servico>.js` ou helper em `scripts/` |
