# 07 — Criação de Memórias (estrutura técnica)

> Este capítulo descreve **como** o sistema de memória funciona tecnicamente. Para o **método** de treinamento (quando salvar, o que salvar), ver `06-treinamento-do-sistema.md`.

---

## Onde as memórias moram

```
~/.claude/projects/<dir-encoded>/memory/
├── MEMORY.md                          ← índice (sempre carregado no contexto)
├── user_<assunto>.md                  ← memórias tipo "user"
├── feedback_<assunto>.md              ← memórias tipo "feedback"
├── project_<assunto>.md               ← memórias tipo "project"
└── reference_<assunto>.md             ← memórias tipo "reference"
```

`<dir-encoded>` é o diretório de trabalho codificado: barras viram hífens. Exemplos:
- Trabalhando em `/root` → `~/.claude/projects/-root/memory/`
- Trabalhando em `/opt/saga` → `~/.claude/projects/-opt-saga/memory/`

**Conclusão prática:** memórias são **por diretório**. O Claude rodando em `/root` lê memórias diferentes do Claude rodando em `/opt/saga`.

> **Dica:** o `saga-runner` faz `cd /opt/saga` antes de chamar `claude -p`. Então o agente operacional usa as memórias de `/opt/saga`. Se você operar interativamente do `/root`, está em outra pasta de memórias. **Treine onde o agente roda em produção** (`/opt/saga`).

---

## Anatomia de um arquivo de memória

```markdown
---
name: Nome da memória
description: Descrição em uma linha — usada para decidir relevância em conversas futuras, seja específico
type: feedback
---

Conteúdo da memória aqui.
Para tipo "feedback" e "project", a estrutura recomendada é:

A regra/fato em uma frase forte.

**Why:** o motivo da regra/fato (incidente, preferência, restrição, deadline)

**How to apply:** quando/onde a regra deve ser aplicada
```

### Frontmatter (YAML entre `---`)

| Campo | Tipo | Obrigatório | O que é |
|---|---|---|---|
| `name` | string | sim | Nome curto e legível (vai no `MEMORY.md`) |
| `description` | string | sim | Hook em uma linha — o agente lê para decidir se essa memória é relevante para a conversa atual |
| `type` | enum | sim | `user` \| `feedback` \| `project` \| `reference` |

### Corpo

Markdown livre. Para `feedback` e `project` use a estrutura **regra + Why + How to apply** porque dá contexto para o agente julgar exceções.

---

## O índice `MEMORY.md`

Este arquivo é **sempre carregado** no contexto do Claude (truncado em ~200 linhas). Conteúdo:

```markdown
- [Nome curto](nome_arquivo.md) — hook de uma linha
- [Outro nome](outro_arquivo.md) — outro hook
- ...
```

Sem frontmatter. Sem categorias. Só uma lista plana de pointers para os arquivos.

**Regras do `MEMORY.md`:**
- Cada linha < 150 caracteres
- Total < 200 linhas
- Hook deve ser uma frase que faz o agente pensar "ah, essa memória é relevante para essa conversa"
- Atualize sempre que adicionar ou remover memória

**Ordem das memórias no índice:** sem regra rígida, mas convém:
1. Identidade e regras inquebráveis primeiro (mais críticas)
2. Perfil do usuário em seguida
3. Equipe e contatos
4. Regras operacionais
5. Integrações e referências

---

## Tipos de memória — quando usar cada

### `user` — sobre você, o operador
**Use quando:** o agente precisa saber quem você é para adaptar a comunicação.

Exemplo:
```markdown
---
name: Perfil do operador
description: empresário, foco em marketing direto, prefere comunicação direta e ações sobre explicações
type: user
---

Sou empresário, atuo principalmente em marketing direto e tráfego pago. Prefiro:
- Mensagens curtas e diretas
- Ação > explicação
- Resultados objetivos com números antes de teoria
- Quando explicar, em linguagem de empresário, não de programador
```

### `feedback` — regras de comportamento
**Use quando:** correção/confirmação de como o agente deve agir.

Exemplo:
```markdown
---
name: Sem em-dashes em mensagens
description: Substituir — e – por pontuação portuguesa normal em todo texto enviado
type: feedback
---

Não usar travessões (— ou –) em mensagens enviadas. Usar pontuação portuguesa normal: vírgula, ponto, parênteses.

**Why:** o operador prefere texto que parece português escrito por brasileiro, não traduzido. Travessão soa "estrangeiro".

**How to apply:** em todo `/send-message`, `/messages/private`, `/messages/group`, e qualquer texto que vire WhatsApp. Não vale para arquivos de código ou documentação interna.
```

### `project` — fatos sobre operação/iniciativas
**Use quando:** decisões, prazos, estado de projetos.

Exemplo:
```markdown
---
name: Lançamento Q2 2026
description: Campanha "Imersão Paradigma" abre inscrições em 15/05 e fecha em 30/05
type: project
---

Campanha "Imersão Paradigma" — turma Q2 2026.

- Abertura: 2026-05-15
- Fechamento: 2026-05-30
- Meta: 50 inscrições
- Canal principal: Click-to-WhatsApp via Meta Ads
- Conta de anúncio: <ACCOUNT_ID> (BM <BM_ID>)

**Why:** prazo definido com a equipe na reunião de 2026-04-20. Calendário travado.

**How to apply:** ao reportar status de campanha, comparar gasto/inscrições com a meta. Após 30/05, considerar campanha encerrada — não cobrar leads como prioridade.
```

### `reference` — onde achar informação externa
**Use quando:** pointer para sistemas/dashboards/contas externas.

Exemplo:
```markdown
---
name: Asaas — financeiro
description: Plataforma de cobrança PIX/boleto, conta operacional do Saga
type: reference
---

Asaas é onde está a operação financeira (cobranças PIX/boleto/cartão).

- URL: asaas.com/login
- Email da conta: <EMAIL_DA_CONTA>
- Token API: salvo em `app_settings.asaas_api_token`
- Helper para o agente: `scripts/asaas.sh` (se existir) ou chamadas curl diretas

**Quando consultar:** ao receber pergunta sobre cobranças, vencimentos, clientes pagantes, ou ao receber pedido de gerar nova cobrança.
```

---

## Boas práticas

### 1. Um conceito por arquivo
Não junte "feedback sobre tom" + "lista de contatos" + "decisão de campanha" no mesmo `.md`. Um arquivo, um conceito. Facilita encontrar, atualizar, remover.

### 2. Nome de arquivo descritivo
- ❌ `feedback_1.md`, `regra_nova.md`, `xyz.md`
- ✅ `feedback_no_em_dashes.md`, `feedback_sem_emoji.md`, `project_lancamento_q2_2026.md`

### 3. Description que ajude o agente a decidir
A `description` é a vitrine. O agente lê o `MEMORY.md`, vê a description, e decide se vale ler o arquivo inteiro.

- ❌ `description: regra importante`
- ✅ `description: nunca enviar duas mensagens idênticas em sequência sem checar histórico — proteção contra loops`

### 4. Marque memórias de identidade como "INQUEBRÁVEL"
Se a regra é absoluta (ex.: "nunca diga meu nome em público"), comece a description com `**INQUEBRÁVEL** — `. O agente trata como hard rule.

### 5. Datas absolutas, não relativas
- ❌ "decisão de ontem"
- ✅ "decisão de 2026-05-04"

Memória persiste; "ontem" perde sentido depois.

### 6. Atualize em vez de duplicar
Antes de criar memória nova, peça: "tem memória sobre isso?" Se já tem, edita. Não cria `feedback_v2_*.md`.

### 7. Quando remover
- A regra deixou de valer (lançamento já passou, contato saiu da equipe).
- A regra contradiz uma nova mais clara.
- A memória nunca foi acionada em 3+ meses (provavelmente irrelevante).

Para remover: deletar o arquivo + remover linha do `MEMORY.md`.

---

## O que **não** salvar em memória

- **Estado de código.** Convenções, paths, estrutura de arquivo são derivados lendo o repo. Não vire snapshot de README.
- **Histórico do Git.** `git log` é a fonte autoritativa.
- **Recipes de bug-fix.** O fix está no commit. A memória rapidamente fica desatualizada.
- **Coisas já em CLAUDE.md.** Se está no CLAUDE.md do projeto, não duplica em memória.
- **Estado efêmero.** "Estou agora trabalhando em X" não é memória — é contexto de conversa.

---

## Workflow recomendado para criar uma memória

### Via DM (mais comum)
1. Você diz: "salva isso: <regra>"
2. Agente sugere o tipo e nome do arquivo (`feedback_xyz.md`)
3. Você confirma ou ajusta
4. Agente cria o arquivo e atualiza `MEMORY.md`

### Via terminal (mais controle)
1. `cd /opt/saga && claude`
2. "Cria memória sobre X"
3. Agente propõe estrutura (frontmatter + corpo) e mostra antes de gravar
4. Você revisa, agente grava

### Edição manual
```bash
nano ~/.claude/projects/-opt-saga/memory/feedback_nova_regra.md
# escreva o conteúdo

# adicionar ao índice
nano ~/.claude/projects/-opt-saga/memory/MEMORY.md
# adicione: - [Nome](feedback_nova_regra.md) — hook
```

Cuidado: edite com o agente parado para não pegar versão antiga em memória de processo (na real Claude Code lê os arquivos no início de cada sessão, então o impacto é só na próxima conversa).

---

## Verificação (smoke test) após criar memória

Em uma **nova** sessão (ou nova conversa em DM), faça uma pergunta que deveria acionar a memória.

Exemplo: salvou "feedback: nunca usar emoji". Em nova conversa, pergunte algo que naturalmente convidaria emoji ("comemora aí, fechou venda!"). Se o agente respondeu sem emoji → memória ativa. Se respondeu com emoji → memória não foi indexada ou está mal-escrita.

---

## Migração entre máquinas

Memórias são portáveis. Para mover para uma nova máquina:

```bash
# Na máquina origem:
tar -czf memorias-saga.tar.gz -C ~/.claude/projects/-opt-saga memory/

# Copia para máquina destino (rsync/scp/cloud):
scp memorias-saga.tar.gz user@nova-vps:/tmp/

# Na máquina destino (após instalar Saga e abrir Claude no /opt/saga):
mkdir -p ~/.claude/projects/-opt-saga
cd ~/.claude/projects/-opt-saga
tar -xzf /tmp/memorias-saga.tar.gz
```

Cuidado com **dados pessoais** no tar: não envie por canais inseguros. Memórias podem conter telefones, nomes, decisões internas.

---

## Backup de memórias

Memórias somem se a VPS pegar um problema. Backup essencial:

```bash
# Adicione ao crontab:
0 4 * * * tar -czf /opt/saga/data/backups/memorias-$(date +\%F).tar.gz -C /root/.claude/projects . 2>/dev/null
```

Mantenha cópia fora da VPS (Drive, S3, outra máquina).

---

## Estrutura de memórias num Saga novo (template inicial sugerido)

Quando subir uma instalação nova, comece criando estes arquivos como base:

```
memory/
├── MEMORY.md
├── user_operador_profile.md          # quem é o dono
├── feedback_identidade_agente.md     # nome do agente, tom, regras inquebráveis
├── feedback_no_autoresponse.md       # se chegar não-whitelist, não responde sem ok
├── feedback_no_duplicate_messages.md # nunca a mesma msg duas vezes
├── feedback_confirmar_antes_executar.md # ack + confirmação antes de ações grandes
└── reference_canais_externos.md      # Asaas, Meta, Cloudflare, etc.
```

Os arquivos podem nascer vazios e serem preenchidos progressivamente. O importante é que o **índice** (`MEMORY.md`) já tenha as entradas — assim o agente sabe que essas memórias existem e pode preenchê-las quando você der as informações.

---

## Como o `MEMORY.md` é exposto ao Claude

Ao iniciar uma conversa, o Claude Code:
1. Lê `~/.claude/CLAUDE.md` (global, se existir).
2. Lê `<cwd>/CLAUDE.md` (do projeto).
3. Lê `~/.claude/projects/<dir-encoded>/memory/MEMORY.md`.
4. **Não lê automaticamente** os arquivos individuais de memória — ele lê apenas o índice.
5. Quando precisa de detalhes, **busca proativamente** o arquivo cujo hook parece relevante.

Implicação: o `MEMORY.md` é **a vitrine**. Se um hook não indica clareza, a memória nunca será aberta.

---

## Tamanho prático

- **Cada arquivo de memória:** 100 a 800 caracteres é o sweet spot. Acima de 2 mil chars, considera quebrar em duas memórias.
- **`MEMORY.md`:** entre 30 e 100 linhas é o sweet spot operacional. Acima de 200 linhas, o agente perde foco.

Em uma operação madura (6+ meses), espere ter ~50-80 memórias indexadas.
