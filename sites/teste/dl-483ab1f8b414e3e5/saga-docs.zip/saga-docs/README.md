# Sistema Saga — Documentação Oficial

> Sistema autônomo de WhatsApp + agente Claude Code rodando em VPS Linux.
> Criado e operado por **Jefferson Henrike**.

---

## O que é o Saga

Saga é um sistema integrado em duas camadas que trabalham juntas:

1. **Worker `saga`** — Daemon Node.js que conecta um número WhatsApp ao servidor via `whatsapp-web.js`, persiste tudo num SQLite, expõe uma API HTTP completa, e dispara webhooks/triggers para o agente.
2. **Daemon `saga-runner`** — Loop bash que monitora o banco, detecta mensagens novas dos remetentes autorizados (whitelist), e invoca o **Claude Code em modo headless** (`claude -p`) para responder, executar tarefas, gerenciar campanhas Meta Ads, criar landing pages, cobrar follow-ups, etc.

Juntos, esses dois componentes formam um **agente operacional 24/7** que responde no WhatsApp do dono, opera campanhas, gerencia equipe e executa tarefas autônomas.

---

## Para que serve este documento

Esta documentação foi escrita com **dois objetivos**:

1. **Replicar o sistema em outra máquina** — qualquer VPS limpa pode virar um Saga seguindo os passos descritos.
2. **Estudar e entender** como o sistema foi construído, suas decisões arquiteturais e como o agente é treinado para ficar mais inteligente com o tempo.

Você pode subir o arquivo `00-AUTO-INSTALL.md` num Claude Code novo e ele vai tentar auto-instalar o sistema lendo este documento como instrução.

---

## Índice

| Arquivo | Conteúdo |
|---------|----------|
| `00-AUTO-INSTALL.md` | Prompt auto-instalável: cole num Claude Code limpo e ele monta o sistema. |
| `01-arquitetura.md` | Visão geral, módulos, fluxo de dados, decisões técnicas. |
| `02-instalacao-manual.md` | Passo a passo humano para instalar o sistema do zero numa VPS. |
| `03-credenciais-e-tokens.md` | Tokens necessários, onde obter cada um, onde colar. |
| `04-worker-modulos.md` | Detalhamento de cada arquivo `.js` do worker `saga`. |
| `05-saga-runner.md` | Daemon do agente: como ele decide rodar, debounce, cooldown, bug `state=ready`. |
| `06-treinamento-do-sistema.md` | **Como treinar o agente para ficar muito inteligente.** Método de feedback, "lembra/salva/anota", confirmações. |
| `07-criacao-de-memorias.md` | Estrutura técnica das memórias: tipos, frontmatter, MEMORY.md, regras. |
| `08-skills-hooks-keybindings.md` | Estado atual do harness Claude Code (settings.json, plugins) e como personalizar. |
| `09-integracoes-externas.md` | Google (Drive/Gmail/Calendar/Contacts), Asaas, Cloudflare, Meta Ads, Anthropic, Groq, ZapSign. |
| `10-operacao-diaria.md` | Runbook: PM2 status, logs, pareamento WhatsApp, restart, backup. |
| `11-troubleshooting.md` | Bugs conhecidos e soluções (state=ready, @lid, wweb timeouts). |
| `12-replicacao-nova-maquina.md` | Guia completo da réplica zero. Versão "humana lendo passo a passo". |
| `13-prompt-auto-documentacao-v2.md` | O prompt v2.0 que gerou esta doc + como reusar para atualizar/regenerar. |

---

## Convenções desta documentação

- **`<PLACEHOLDER>`** — valor que você precisa preencher na sua instalação (token, domínio, telefone, etc.).
- **`<<DEFINIR: descrição>>`** — ponto que ficou em aberto na geração; precisa de decisão sua antes de seguir.
- Todos os caminhos absolutos assumem `/opt/saga/` como diretório de instalação. Se você instalar em outro path, ajuste consistentemente.
- Comandos com `sudo`/`root` assumem você tem acesso root na VPS.

---

## Stack resumida

| Camada | Tecnologia |
|--------|------------|
| Sistema operacional | Debian/Ubuntu LTS |
| Runtime | Node.js 20+ |
| Web framework | Express 4 |
| Banco de dados | SQLite (better-sqlite3, modo WAL) |
| WhatsApp client | whatsapp-web.js (puppeteer + Chromium) |
| Process manager | PM2 (com pm2-logrotate) |
| Reverse proxy + SSL | Nginx Proxy Manager (Docker) ou Nginx + Certbot direto |
| DNS | Cloudflare (gerenciado via API) |
| Agente | Claude Code CLI (`claude -p` em modo headless) |
| LLM principal | Claude Opus 4.7 (1M context) |
| LLM Fase 2 (auto-resposta não-whitelist) | Claude Sonnet 4.6 |
| Transcrição de áudio | Groq Whisper Large v3 |
| TTS | Microsoft Edge TTS (`pt-BR-AntonioNeural`) |

---

## Início rápido

```bash
# 1. Clone numa VPS limpa (Debian/Ubuntu)
git clone <REPO_OU_TARBALL_DO_SAGA> /opt/saga

# 2. Rode bootstrap (instala tudo)
cd /opt/saga
sudo bash scripts/bootstrap.sh

# 3. Configure .env com seus tokens (ver 03-credenciais-e-tokens.md)
cp .env.example .env
nano .env

# 4. Rode migrations
npm run migrate

# 5. Suba via PM2
pm2 start ecosystem.config.js
pm2 save
pm2 startup

# 6. Pareie o WhatsApp
curl -s http://127.0.0.1:3002/qr | jq
# (siga link/QR no painel ou pairing code)
```

Detalhes completos em `02-instalacao-manual.md`.
