# 05 — `saga-runner` (daemon do agente)

> O `saga-runner` é o que transforma o sistema de "API HTTP que responde no WhatsApp" em **agente autônomo**. Ele é um loop bash de ~80 linhas que polla o SQLite e dispara o Claude Code em modo headless quando há mensagem da whitelist.

---

## O script (`scripts/agent-runner.sh`)

Local: `/opt/saga/scripts/agent-runner.sh`. Rodado via PM2 (processo `saga-runner`).

### Responsabilidade única

Detectar mensagens **acionáveis** (de quem é autorizado a acordar o agente) e disparar `claude -p` com um prompt mínimo, deixando o trabalho real para o Claude Code seguir o `CLAUDE.md` do diretório.

### Pseudocódigo

```
loop forever:
    PENDING = SELECT COUNT(*) FROM messages
              WHERE processed_by_agent=0
                AND from_me=0
                AND ( contact_phone IN (whitelist)
                   OR chat_id = team_group_jid
                   OR contact_phone IN (team-authorized via contact_settings) )

    if PENDING > 0:
        if outro `claude -p` ainda rodando:
            wait COOLDOWN (15s) e continue
        sleep DEBOUNCE (8s) — caso venha mais msg na sequência
        re-check PENDING (pode ter sido processado por outra coisa)
        if PENDING ainda > 0:
            spawn `claude -p "<prompt padrão>"` com timeout 300s
            sleep COOLDOWN (15s)
    else:
        sleep POLL (5s)
```

### Configurações internas

| Variável | Valor | O que controla |
|---|---|---|
| `DB` | `/opt/saga/data/worker.db` | Banco a pollar |
| `WORKER_DIR` | `/opt/saga` | cwd do `claude -p` (para ele achar o `CLAUDE.md`) |
| `CLAUDE_BIN` | `/root/.nvm/versions/node/v20.20.2/bin/claude` | Caminho fixo do binário (evita PATH) |
| `DEBOUNCE` | 8s | Espera após detectar pendência (caso venha mais msg) |
| `POLL` | 5s | Intervalo de verificação quando idle |
| `COOLDOWN` | 15s | Espera após cada execução de `claude -p` |
| `RUN_TIMEOUT` | 300s | Timeout máximo por execução do `claude -p` |

### Query de detecção de pendência

```sql
SELECT COUNT(*) FROM messages
WHERE processed_by_agent=0 AND from_me=0 AND (
  contact_phone IN ('<TELEFONE_WHITELIST_1>', '<TELEFONE_WHITELIST_2>')
  OR chat_id = COALESCE(
       (SELECT value FROM app_settings WHERE key='internal_team_group_jid'),
       ''
     )
  OR contact_phone IN (
    SELECT phone FROM contact_settings
    WHERE api_replies_enabled=0
      AND set_by IN ('lucas_approval','team_group_auto')
  )
);
```

> A query é hardcoded no script — para adicionar novos whitelisted, edite o script ou (preferível) adicione o phone em `contact_settings` com `api_replies_enabled=0, set_by='lucas_approval'`. (O `set_by='lucas_approval'` é nome legado, equivale a "autorização explícita do dono".)

### Por que o filtro `from_me=0`?

Mensagens com `from_me=1` são respostas do próprio worker. Sem esse filtro, o agente entraria em loop respondendo às próprias mensagens.

### Por que a verificação `pgrep -af "claude -p "`?

Para não rodar dois `claude -p` simultâneos. Se há um em vôo, espera. Importante: **só bloqueia outros runs do `claude -p`**, não bloqueia sessões interativas do Claude Code (essas usam `claude` sem `-p`). Sessão interativa do Jefferson e o daemon coexistem.

### Prompt enviado ao `claude -p`

```
Mensagens whitelist pendentes em data/worker.db (processed_by_agent=0 AND from_me=0).
Siga o CLAUDE.md deste diretório: leia o histórico recente do(s) contato(s) com pendência,
responda apropriadamente via scripts/wapi.sh, e marque processed_by_agent=1 para todos os
IDs lidos. Não peça confirmação para whitelist (Jefferson <TELEFONE>) nem equipe autorizada.
Seja conciso. Termine quando todas estiverem processadas.
```

O prompt é **deliberadamente curto**. Toda a lógica detalhada (como ler, como filtrar, como responder, como marcar) está no `CLAUDE.md` do diretório. O Claude Code carrega o CLAUDE.md automaticamente porque o `cd "$WORKER_DIR"` foi feito antes.

### Stdout/stderr

Tudo vai para `logs/agent-runner.log`. PM2 também captura para `logs/agent-runner.out.log` e `logs/agent-runner.err.log`. Linhas formatadas com `[<timestamp UTC>] <mensagem>`.

---

## Regras importantes

### 1. O daemon não interpreta mensagens.
Ele só detecta que **existe** mensagem pendente e dispara. Toda decisão de conteúdo é responsabilidade do `claude -p` lendo o `CLAUDE.md`.

### 2. O daemon não envia mensagens diretamente.
O `claude -p` é quem chama `scripts/wapi.sh POST /send-message`. Isso garante que toda saída passa pela `send-queue` do worker (anti-ban, dedupe, rate limit).

### 3. O daemon não atualiza `processed_by_agent`.
Quem marca como processado é o próprio Claude no fim da execução. Se o Claude crashar antes de marcar, a mensagem volta a ser pendente — o daemon vai re-disparar. Isso é por design (idempotência).

### 4. O daemon assume que `claude` está autenticado.
Na primeira instalação você precisa rodar `claude` interativamente uma vez (com login Anthropic) para o token ficar salvo em `~/.claude/`. Sem isso, o `claude -p` falha com "not authenticated".

### 5. Identidade do agente
O agente herda a identidade definida em:
- `~/.claude/projects/<dir-encoded>/memory/MEMORY.md` (memórias persistentes do agente)
- `<WORKER_DIR>/CLAUDE.md` (instruções específicas do projeto)
- `~/.claude/settings.json` (permissions + skills + hooks globais)

A identidade ZEUS (ou o nome que você escolher) é construída pelas memórias `feedback_zeus_identidade.md` e similares. Ver `06-treinamento-do-sistema.md`.

---

## Bug conhecido: `state=ready` com `client null`

**Sintoma:** após `pm2 restart saga`, o `/status` retorna `state: 'ready'` mas qualquer envio falha (timeout silencioso). O `meNumber` vem `null`.

**Causa provável:** race condition no boot — a state machine sinaliza `ready` cedo demais, antes do client whatsapp-web.js estar 100% inicializado e referenciado pelo módulo `wa`.

**Diagnóstico:**
```bash
curl -s http://127.0.0.1:3002/status \
  -H "Authorization: Bearer $(grep ^API_TOKEN /opt/saga/.env | cut -d= -f2)" | jq
# Se "state":"ready" e "meNumber":null → bug está presente
```

**Fix manual:**
```bash
pm2 restart saga
sleep 30  # aguardar boot completo
# repete o curl — agora meNumber deve estar populado
```

**Mitigação automática:** o `watchdog.js` detecta cliente parado e força reinit. Se isso for frequente, aumentar `AUTH_WATCHDOG_MS` ou adicionar verificação periódica explícita do `meNumber`.

**Impacto no `saga-runner`:** se este bug acontece, o agente tenta responder mas o worker engasga, mensagens enfileiram em `send_queue` com `status='pending'` ou `status='sending'` indefinido. Após o restart, a fila se recupera (`recoverStuck` no boot da queue) e tudo fica entregue.

Mais detalhes em `11-troubleshooting.md`.

---

## Coexistência com sessão interativa

Enquanto o `saga-runner` roda em loop, você pode abrir um Claude Code interativo no mesmo servidor:
```bash
cd /opt/saga
claude
```
Esta sessão **não bloqueia** o daemon (o filtro do `pgrep -af "claude -p "` exige o `-p`, que sessão interativa não tem). O daemon segue respondendo enquanto você opera.

**Risco aceito:** se você está em sessão interativa pedindo algo no terminal e o daemon dispara em paralelo, podem aparecer **respostas duplicadas** ao mesmo contato (você responde manualmente e o daemon também). O CLAUDE.md tem a regra "**nunca mandar a mesma mensagem duas vezes**" para mitigar — o agente checa histórico antes de responder. Mas em janela curta, dupla é possível.

---

## Métricas e observabilidade

Quantas vezes o daemon disparou hoje:
```bash
grep "spawning claude -p" /opt/saga/logs/agent-runner.log \
  | awk -v today="$(date -u +%F)" '$0 ~ today' | wc -l
```

Tempo médio por execução (a partir do log):
```bash
grep -E "spawning|finished" /opt/saga/logs/agent-runner.log \
  | awk -v today="$(date -u +%F)" '$0 ~ today' \
  | tail -100
```

Última execução:
```bash
tail -50 /opt/saga/logs/agent-runner.log
```

---

## Como mudar o comportamento do daemon

| Quero | Mexo em |
|---|---|
| Adicionar/remover whitelist | Edita o `PENDING_QUERY` no script (lista hardcoded) ou usa `contact_settings` |
| Mudar o prompt enviado ao `claude -p` | Edita o heredoc do `claude -p` no script |
| Aumentar timeout por execução | Variável `RUN_TIMEOUT` |
| Mudar polling interval | Variável `POLL` |
| Mudar debounce (esperar mais antes de disparar) | Variável `DEBOUNCE` |
| Permitir múltiplos `claude -p` paralelos | Remover o `pgrep` (não recomendado — risco de stomp na DB) |
| Trocar binário do Claude | Variável `CLAUDE_BIN` |

Após editar, `pm2 restart saga-runner`.

---

## Health check do daemon

Sinais de que o daemon está saudável:
- `pm2 status` mostra `saga-runner` como `online` e uptime crescendo
- `logs/agent-runner.log` tem linhas recentes (últimos 5-10s)
- Nenhuma linha `claude -p finished exit=124` (124 = timeout)
- Mensagens da whitelist estão recebendo resposta em < 30s

Sinais de problema:
- Daemon `errored` no PM2 → reinicia 16x e desliga; ver `logs/agent-runner.err.log`
- `exit=124` em todas as runs → timeout do Claude Code (modelo lento ou loop)
- `0 pending detected` mesmo com mensagem nova → query não está casando; verificar whitelist
- `claude -p finished exit=1` consecutivo → erro no agente; ver `logs/agent-runner.log`
