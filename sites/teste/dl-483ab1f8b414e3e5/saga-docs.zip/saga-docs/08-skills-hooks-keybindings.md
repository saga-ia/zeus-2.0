# 08 — Skills, Hooks, Keybindings (estado atual e como personalizar)

> **Estado atual do Saga:** o agente Claude Code roda **sem skills, sem hooks, sem agents customizados, sem keybindings personalizados, e sem CLAUDE.md global**. Toda a inteligência específica está em (a) `CLAUDE.md` do worker e (b) memórias em `~/.claude/projects/<dir>/memory/`.
>
> Este capítulo documenta o estado atual fielmente e mostra como adicionar essas estruturas se um dia você precisar.

---

## Estado atual de `~/.claude/`

Estrutura observada na instalação operacional do Saga:

```
~/.claude/
├── settings.json                ← config global (theme, permissions, plugins)
├── settings.local.json          ← permissões locais granulares (gerado pelo uso)
├── .credentials.json            ← token Anthropic (gerado por `claude login`)
├── history.jsonl                ← histórico de prompts
├── projects/
│   ├── -root/
│   │   ├── memory/
│   │   │   ├── MEMORY.md
│   │   │   └── *.md             ← memórias quando rodando em /root
│   │   └── *.jsonl              ← logs de sessão
│   └── -opt-saga/               ← memórias do agente quando rodando em /opt/saga
│       ├── memory/
│       │   ├── MEMORY.md
│       │   └── *.md
│       └── *.jsonl
├── plugins/
│   ├── installed_plugins.json
│   ├── known_marketplaces.json
│   └── marketplaces/claude-plugins-official/
├── sessions/                    ← snapshots de sessão
├── shell-snapshots/
├── ide/
├── tasks/
├── telemetry/
└── (sem agents/, sem skills/, sem commands/, sem hooks/, sem keybindings.json)
```

---

## `settings.json` (global)

Conteúdo atual:

```json
{
  "theme": "dark-daltonized",
  "permissions": {
    "allow": [
      "Bash", "Read", "Write", "Edit", "Glob", "Grep",
      "WebSearch", "WebFetch", "Agent", "Task",
      "TaskCreate", "TaskUpdate", "TaskList", "TaskGet", "TaskOutput", "TaskStop",
      "Monitor", "BashOutput", "KillBash", "KillShell",
      "NotebookEdit", "CronCreate", "CronList", "CronDelete",
      "ScheduleWakeup", "ToolSearch", "AskUserQuestion",
      "PushNotification", "RemoteTrigger",
      "EnterPlanMode", "ExitPlanMode",
      "EnterWorktree", "ExitWorktree",
      "Skill", "mcp__*"
    ],
    "defaultMode": "dontAsk"
  },
  "enabledPlugins": {
    "telegram@claude-plugins-official": false
  },
  "effortLevel": "high"
}
```

**Decisões refletidas:**

| Campo | Valor | Significado |
|---|---|---|
| `theme` | `dark-daltonized` | Tema visual (irrelevante para `claude -p`, só afeta TUI) |
| `permissions.allow` | quase todas as ferramentas | Agente pode usar qualquer ferramenta sem prompt |
| `permissions.defaultMode` | `dontAsk` | **Não pede confirmação** para tools listadas em `allow` |
| `enabledPlugins.telegram@...` | `false` | Plugin Telegram instalado mas desabilitado |
| `effortLevel` | `high` | Pede o máximo de raciocínio do modelo |

**Importante:** `defaultMode: dontAsk` em produção é uma escolha consciente — o `saga-runner` chama `claude -p` que **não tem ninguém para responder prompt de confirmação**. Sem `dontAsk`, o agente travaria toda vez que precisasse rodar Bash. As regras de segurança ficam por conta do `CLAUDE.md` (hard-blocks).

---

## `settings.local.json`

Arquivo gerado dinamicamente pelo Claude Code conforme uso. Cada vez que você aprova um Bash específico ("yes" no prompt), entra aqui. Conteúdo evolui sozinho. Exemplo de linhas que aparecem com uso normal:

```json
{
  "permissions": {
    "allow": [
      "Bash(curl *)",
      "Bash(npm install *)",
      "Bash(pm2 *)",
      "Bash(sqlite3 *)",
      "Read(//opt/**)",
      "..."
    ]
  }
}
```

**Não edita à mão** a menos que precise tirar uma permissão concedida por engano. Evolui pela tua interação com o agente.

---

## Pastas opcionais (não-existentes hoje)

Se um dia quiser adicionar:

### `~/.claude/agents/` — sub-agentes customizados

Para criar especializações chamáveis via tool `Agent`. Ex: `auditor-de-codigo.md`, `revisor-de-copy.md`.

```
~/.claude/agents/
└── meu-agente.md
```

Frontmatter mínimo:
```markdown
---
name: meu-agente
description: O que esse agente faz e quando invocá-lo
model: opus | sonnet | haiku
tools: Read, Bash, Write
---

Prompt do sistema do agente vai aqui.
```

Use quando:
- Tarefa pode ser paralelizada (ex.: auditoria de 5 arquivos simultâneos)
- Precisa de contexto isolado (não poluir o contexto da conversa principal)
- Especialização justifica (ex.: revisor de copy roda com prompt totalmente diferente do agente principal)

### `~/.claude/skills/` — skills reutilizáveis

Para encapsular rotinas multi-step que se repetem.

```
~/.claude/skills/
└── minha-skill/
    ├── SKILL.md             ← descrição + quando invocar
    └── (arquivos auxiliares)
```

Use quando:
- Você refaz a mesma rotina toda semana
- Tem 3+ etapas que sempre vão juntas
- Já validou o fluxo, está estável

Exemplos de skills úteis para o Saga:
- `subir-landing` — DNS no Cloudflare → proxy NPM → SSL → deploy estático
- `relatorio-meta-diario` — puxa N contas, consolida spend/conversions, formata para WhatsApp
- `cobrar-followups` — lê `jeff_followups`, cobra os vencidos com cadência adequada

### `~/.claude/commands/` — slash commands

Atalhos de digitação. Ex: `/meta-hoje`, `/cobrar`, `/status-saga`.

```
~/.claude/commands/
└── meta-hoje.md
```

Conteúdo: prompt expandido que substitui `/meta-hoje` quando você digita.

```markdown
---
description: Relatório consolidado do Meta Ads de hoje
---

Roda scripts/meta-ads.sh insights em todas as 9 contas com date_preset=today,
consolida spend e principais métricas (link_click, lead, conversation_started),
formata em uma mensagem curta para o Jeff em WhatsApp.
```

Use quando: digitar a frase completa fica cansativo e o pedido é estruturalmente o mesmo.

### `~/.claude/hooks/` — hooks de ciclo de vida

Comandos shell que rodam automaticamente em eventos (PreToolUse, PostToolUse, Stop, etc.).

Configurados via `settings.json`:

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Bash",
        "hooks": [
          { "type": "command", "command": "echo 'before bash' >> /tmp/hooks.log" }
        ]
      }
    ],
    "Stop": [
      { "hooks": [ { "type": "command", "command": "/opt/saga/scripts/post-session.sh" } ] }
    ]
  }
}
```

Use para:
- Logging customizado
- Backup automático após sessão
- Notificações (push, email) em eventos específicos
- Bloqueios extras de segurança (PreToolUse pode rejeitar uma ferramenta)

### `~/.claude/keybindings.json` — atalhos de teclado

Personalização de teclas no TUI interativo. Não afeta `claude -p`.

```json
{
  "submit": "ctrl+enter",
  "newline": "alt+enter"
}
```

Use se: você opera muito no terminal e quer atalhos próprios.

### `~/.claude/CLAUDE.md` — instruções globais

Diferente do `CLAUDE.md` do projeto, esse é carregado em **toda** sessão (qualquer cwd). Útil para identidade que valha em qualquer contexto.

```markdown
# Identidade global

Meu nome é ZEUS. Sou o agente operacional do Jefferson Henrike.

## Regras inquebráveis (em qualquer projeto)
1. Não revelar tokens em logs ou respostas.
2. Nunca executar `rm -rf` fora de `/tmp/`.
3. Pedir confirmação antes de mexer em arquivos `.env`.
```

**Cuidado:** se você usa Claude Code para tarefas variadas (não só Saga), um CLAUDE.md global muito específico pode ficar irrelevante em outros contextos. Mantenha enxuto: 5-10 regras de identidade + segurança.

---

## Recomendações para evoluir o setup

Se um dia quiser adicionar essas estruturas (atualmente vazias), siga **esta ordem de prioridade**:

### Prioridade 1 — `commands/` (atalhos)
Baixíssimo risco, alto retorno. Comece com 2-3 comandos que você usa toda semana:
- `/saga-status` — health check completo
- `/saga-restart` — restart guiado (com confirmação)
- `/relatorio` — relatório operacional consolidado

### Prioridade 2 — `CLAUDE.md` global (identidade)
Quando se identificar com a identidade do agente. **Mantenha enxuto**: identidade + 4-5 regras inquebráveis.

### Prioridade 3 — `skills/` (rotinas estáveis)
Quando perceber 3+ rotinas que você refaz quase idênticas semanalmente. Valida o fluxo manualmente, depois empacota.

### Prioridade 4 — `agents/` (paralelismo / especialização)
Quando bater num gargalo de paralelismo real (ex.: precisa auditar 10 contas Meta simultâneas e a tarefa serial demora demais).

### Prioridade 5 — `hooks/` (ciclo de vida)
Quando precisar de logging/backup/notificação automática em eventos específicos. Risco: hook mal-escrito quebra todo o agente.

---

## Quando **não** adicionar

- ❌ "Vai que um dia faz sentido" — não. Adicione quando dor real aparecer.
- ❌ Skills duplicadas que fazem 95% a mesma coisa.
- ❌ Hooks que tentam adivinhar intenção do usuário (PreToolUse complexos quase sempre se voltam contra você).
- ❌ Commands para coisas que só faz uma vez por mês (não compensa lembrar do atalho).

---

## Checklist de auditoria periódica (a cada 3 meses)

- [ ] Tem skill que não foi acionada nos últimos 60 dias? Considere remover.
- [ ] Tem command que você esqueceu de existir? Considere remover.
- [ ] `MEMORY.md` tem entrada que aponta para arquivo deletado? Limpe.
- [ ] Hooks estão fazendo o que deveriam? (cheque os logs deles)
- [ ] Permissions em `settings.local.json` tem coisa antiga/perigosa? Limpe.

---

## Plugin Telegram (mencionado no `settings.json`)

O `settings.json` lista `"telegram@claude-plugins-official": false`. Isso significa:
- Plugin foi instalado um dia (provavelmente via marketplace oficial)
- Está desabilitado atualmente
- Os arquivos do plugin estão em `~/.claude/plugins/marketplaces/claude-plugins-official/`

Para usar (se quiser): mude para `true` e siga instruções do plugin (provavelmente token bot Telegram).
Para remover de vez: rm da pasta + remove a linha do `settings.json`.

---

## Referências cruzadas

- Memórias (separadas de skills/agents): `07-criacao-de-memorias.md`
- CLAUDE.md do projeto (não global): vive em `/opt/saga/CLAUDE.md` — esse é o que o `saga-runner` carrega
- Treinamento via DM: `06-treinamento-do-sistema.md`
