# 04 — Módulos do Worker `saga`

> Detalhamento de cada arquivo `.js` do diretório `src/`. Use este arquivo quando precisar mexer em código ou estender funcionalidade.

---

## Boot

### `src/index.js`
Ponto de entrada. Sequência:
1. Carrega `config` (lê `.env`) e valida.
2. Importa `db` — isso já dispara migrations automaticamente.
3. Cria `outbound` (disparador de webhooks).
4. Cria `wa` (gerenciador WhatsApp) com callbacks.
5. Cria `queue` (fila de envio anti-ban).
6. Constrói `app` Express e `app.listen(port, host)`.
7. Inicia `outbound.start()`, `queue.start()`, `wa.init()`.
8. Inicia `mchat_poller` (Instagram comment-to-DM).
9. Registra handlers de SIGINT/SIGTERM/uncaughtException para shutdown gracioso (timeout 14s).

Quando o servidor está pronto, manda `process.send('ready')` para o PM2 (que tem `wait_ready: true`).

### `src/server.js`
Constrói a app Express:
- Helmet (CSP customizado liberando Tailwind CDN e Google Fonts).
- CORS bloqueado por default (`origin: false`).
- Body limit 25 MB (suporta upload de mídia).
- Cookie parser para JWT do painel.
- Rate limit: 20 req/min em `/auth`, 600 req/min nas demais.
- `optionalAuth` em todas as rotas, `requireAuth` nas protegidas.
- Log de cada request em `api_logs`.
- Servidor de estáticos em `/public/` com headers CORS liberados (necessário para Meta carregar imagens).
- Roteia: `/health`, `/auth`, `/inscricao` (públicos), `/status`, `/qr`, `/messages`, `/groups`, `/send-*`, `/history`, `/contacts`, `/webhooks`, `/admin`, `/session`, `/agent` (autenticados), `/docs.json`, `/docs` (JWT-only).
- Error handler centralizado em `errorHandler`.

### `src/config.js`
Lê `.env`, normaliza tipos numéricos, e valida que `API_TOKEN`, `JWT_SECRET` e `ADMIN_PASSWORD_HASH` estão presentes (se faltar, falha com `EINVALIDCONFIG`).

`agentWhitelist` é processada: cada número vira só dígitos, depois pega os 9 últimos (fail-safe contra variação de DDI/DDD na comparação).

### `src/logger.js`
Pino com pretty-print em dev, JSON em prod. Level via `LOG_LEVEL` no `.env`.

### `src/openapi.json`
Spec OpenAPI 3.0 completa da API HTTP. Servida em `/docs.json` (raw) e `/docs` (UI Swagger). Útil para clientes humanos e para agentes externos consumirem a API.

---

## Auth (`src/auth/`)

### `middleware.js`
Três middlewares:
- `optionalAuth`: tenta autenticar (Bearer ou JWT cookie), não falha se não houver.
- `requireAuth`: aceita Bearer (`API_TOKEN`) **OU** JWT (cookie do painel). Bearer é o que `wapi.sh` usa.
- `requireJwt`: só JWT (para `/docs`).

Popula `req.auth = { type: 'bearer'|'jwt'|'none' }`.

### `jwt.js`
Emite e verifica JWT com `JWT_SECRET`. TTL configurável via `JWT_TTL_DAYS` (padrão 7).

---

## DB (`src/db/`)

### `index.js`
Abre `better-sqlite3` em modo WAL, configura `synchronous=NORMAL`, registra função `regexp` SQL. Roda migrations automaticamente.

Exporta `{ db, close }`.

### `migrations.js`
Lê arquivos numerados de `migrations/*.sql` e aplica em ordem em uma tabela `_migrations`. Idempotente (não reaplica os já aplicados).

### `migrations/`
Schema versionado em arquivos SQL:

| Arquivo | O que adiciona |
|---|---|
| `001_initial.sql` | `messages`, `chats`, `contacts`, `send_queue`, `webhooks`, `webhook_deliveries`, `api_logs` |
| `002_agent_processing.sql` | `messages.processed_by_agent` (default 1; whitelist insere com 0) |
| `003_transcription.sql` | `messages.transcription`, `messages.transcription_status` |
| `004_contact_aliases.sql` | `contact_aliases` (phone ↔ @c.us ↔ @lid), `messages.contact_phone` |
| `005_api_reply.sql` | `app_settings`, `contact_settings`, `api_reply_log` (Fase 2) |
| `006_pqv_referrals.sql` | `pqv_referrals` + settings de campanha |
| `007_pqv_referrer_email.sql` | `pqv_referrals.referrer_email` |
| `008_google_oauth.sql` | `google_oauth_tokens` |
| `009_mchat.sql` | `mchat_processed_comments`, `mchat_settings` (Instagram comment-to-DM) |
| `010_inscricoes.sql` | `inscricoes` (form público de imersão) |
| `011_sessoes_outlier.sql` | `sessoes_individuais_outlier`, `sessoes_individuais_log` |

Para adicionar uma nova migration: crie `0XX_descricao.sql` (numeração sequencial), use `IF NOT EXISTS` para idempotência, restart do worker aplica.

---

## WhatsApp (`src/wa/`)

### `client.js` (~600 linhas, coração do worker)
Cliente `whatsapp-web.js` configurado:
- `LocalAuth({ dataPath: config.authPath, clientId: config.clientId })` — sessão persistida em `data/.wwebjs_auth/`.
- Puppeteer com `executablePath: config.chromiumPath` (Chromium nativo, não baixa o do Puppeteer).
- Eventos tratados:
  - `qr` → salva em memória (servido por `/qr`).
  - `ready` → marca state machine como `ready`, popula `app_settings.worker_lid_user`.
  - `authenticated`, `auth_failure`, `disconnected`, `change_state` → atualizam `state.js`.
  - `message_create` → ponto de entrada principal:
    - Resolve `phone` canônico via `contact-resolver`.
    - Detecta whitelist (`isWhitelistedPhone`) e equipe autorizada (`isTeamAuthorizedPhone`).
    - Se for áudio (`type='ptt'` ou `'audio'`), baixa, transcreve via Groq, atualiza `transcription`.
    - Se for mídia (imagem/PDF/vídeo), baixa para `data/media/`, atualiza `media_path`.
    - Decide `processed_by_agent`:
      - `0` se whitelist, equipe-autorizada, em grupo da equipe, mencionou o agente, ou é reply a msg sua.
      - `1` caso contrário.
    - INSERT em `messages` (com OR IGNORE pelo `message_id` para idempotência).
    - Dispara webhook outbound `message.received`.
    - Se não-whitelist e Fase 2 ativa, agenda `apiReply.maybeReply` (debounce).
  - `message_ack` → atualiza `messages.ack`.
  - `group_join` → se o worker foi adicionado, manda DM para Jefferson perguntando se é o "grupo da equipe".
- `setQueue(queue)` — recebe a fila de envio para enfileirar (não envia direto).
- `init()` — chama `killZombieChrome()` antes para limpar zumbis Chromium antes de subir.
- `shutdown()` — destrói o cliente e fecha Puppeteer.

### `state.js`
Máquina de estados simples: `disconnected` → `qr` → `connecting` → `ready` (e variações). Mantém `since`, `meNumber`, `meName`. Exposto pelo endpoint `/status`.

### `watchdog.js`
A cada `AUTH_WATCHDOG_MS` (padrão 2 min), verifica se o cliente respondeu eventos. Se ficou parado, força reinit. Mitigação para travamentos silenciosos do Puppeteer.

### `typing.js`
Calcula tempo de digitação realista: `len * TYPING_PER_CHAR_MS`, capado por `TYPING_MAX_MS`. Usado pela fila para simular digitação humana.

### `dedupe.js`
`TimedSet` — set com TTL automático. Usado para deduplicar mensagens dentro de janela de 60s (evita reenvio em retries).

### `contact-resolver.js`
Resolve `phone` ↔ `@c.us` ↔ `@lid`. Cache em memória + persistência em `contact_aliases`. Quando recebe mensagem com JID novo, chama `client.getContactById` para descobrir o phone real (LID é opaco — não é só "últimos 9 dígitos do JID").

**Função-chave:** `resolvePhone(jid)` → retorna phone canônico (só dígitos) ou `null`.

---

## Queue (`src/queue/`)

### `send-queue.js`
Fila SQLite-backed para envio anti-ban. Características:
- INSERT em `send_queue` enfileira; status `pending` → `sending` → `sent` (ou `error`).
- `pickNext` pega o de menor prioridade + menor ID.
- Antes de enviar:
  - Aplica delay aleatório `SEND_MIN_DELAY_MS`–`SEND_MAX_DELAY_MS` (padrão 3-7s).
  - Verifica burst: se já enviou `SEND_BURST_LIMIT` (30) nos últimos `SEND_BURST_WINDOW_MS` (5 min), aguarda.
  - Simula digitação via `typing.js`.
- Timeout 45s por envio (`SEND_TIMEOUT_MS`).
- Retry com backoff exponencial até `MAX_RETRY=3`. Após esgotar, status vai para `error`.
- Dedup por `content_hash` (SHA-256 dos primeiros 16 chars do `JSON.stringify({chat_id,kind,payload})`) com janela de 60s.
- `kind` suportados: `text`, `media`, `audio`, `react`, `reply`.

---

## Routes (`src/routes/`)

| Arquivo | Rotas | O que faz |
|---|---|---|
| `health.js` | `GET /health` | Liveness simples (público) |
| `status.js` | `GET /status` | Estado WhatsApp (state, meNumber, meName, since) |
| `qr.js` | `GET /qr`, `GET /qr?phone=` | QR atual ou pairing code para um número |
| `auth.js` | `POST /auth/login`, `POST /auth/logout` | Painel admin (gera JWT cookie) |
| `messages.js` | `GET /messages`, `POST /messages/<id>/reply`, `POST /messages/<id>/react`, `POST /messages/private`, `POST /messages/group` | CRUD mensagens |
| `groups.js` | `GET /groups`, `POST /groups`, `PATCH /groups/<jid>/name`, `DELETE /groups/<jid>`, `POST /groups/<jid>/participants`, etc. | CRUD grupos + participantes (incluindo `/groups/join`, `/groups/promote-bulk`) |
| `send.js` | `POST /send-message`, `POST /send-media`, `POST /send-audio` | Envio livre (entram na queue) |
| `history.js` | `GET /history?chatId=&limit=` | Histórico paginado |
| `contacts.js` | `GET /contacts`, `POST /contacts/check` | Lista contatos / verifica se número tem WhatsApp |
| `webhooks.js` | `GET/POST/DELETE /webhooks` | CRUD webhooks de saída |
| `admin.js` | `GET /admin/stats`, `/admin/queue`, `/admin/queue/flush`, `/admin/api-replies/*` | Painel admin (totais, fila, panic Fase 2, opt-out por contato) |
| `session.js` | `POST /session/logout`, `/session/restart`, `/session/read` | Gerenciamento da sessão WhatsApp |
| `agent.js` | `POST /agent/speak` | TTS Edge → áudio OGG/Opus → enfileira como `/send-audio` |
| `inscricao.js` | `GET /inscricao/`, `POST /inscricao/submit` | Form público de inscrição (landing) |
| `static-html.js` | `GET /<arquivo.html>` | Serve HTML estático com cookie redirect (autenticação leve) |

---

## Webhooks (`src/webhooks/`)

### `outbound.js`
Disparador de webhooks de saída. Eventos disponíveis: `message.received`, `message.sent`, `message.ack`, `message.edit`, `status.changed`. Persiste cada delivery em `webhook_deliveries` com retry exponencial até 5 tentativas.

---

## Agent (`src/agent/`)

### `notify.js`
Helpers de whitelist:
- `isWhitelistedPhone(phone)` — checa últimos 9 dígitos contra `config.agentWhitelist`.
- `isTeamAuthorizedPhone(phone)` — checa `contact_settings.api_replies_enabled=0 AND set_by IN ('team_group_auto','lucas_approval')`. (O `set_by` herdou o nome do projeto original; pode renomear na próxima iteração.)
- `labelForPhone(phone)` — devolve nome humano para logs.

### `api-reply.js`
Fase 2 — auto-resposta para não-whitelist via API Anthropic direto. Pipeline:
1. Recebe `phone, chatId, messageId` da `client.js`.
2. Verifica `app_settings.api_replies_panic`. Se = `1`, ignora.
3. Verifica `contact_settings.api_replies_enabled` para o phone. Se `0`, ignora.
4. Aplica debounce por contato (`api_reply_debounce_ms`, padrão 8000ms).
5. Carrega histórico (últimas N mensagens onde N = `api_reply_history_limit`).
6. Monta prompt (system prompt + histórico) e chama Anthropic API com modelo de `api_reply_model`.
7. Enfileira a resposta na `send-queue`.
8. INSERT em `api_reply_log` com tokens, status, etc.

### `mchat_poller.js`
Loop de polling do Instagram Graph API. A cada `mchat_settings.poll_interval_ms`:
- Busca comentários novos em mídias do IG do dono.
- Para cada comentário que tem keyword (`mchat_settings.keywords`), envia comment-reply pública e DM.
- Persiste em `mchat_processed_comments` para idempotência.

### `mchat_sheet.js`
Helper de planilha (export para Google Sheets). Estado: legacy / opcional.

---

## Audio (`src/audio/`)

### `transcribe.js`
Recebe path de áudio OGG/Opus, posta para Groq Whisper Large v3, retorna `{ text, status, model }`. Timeout 30s. Falha gracefully com `status='failed'`.

### `tts.js`
Edge TTS (Microsoft Edge Read Aloud). Usa biblioteca `msedge-tts`. Voz padrão `pt-BR-AntonioNeural`, customizável via `TTS_VOICE`, `TTS_RATE`, `TTS_PITCH`. Saída OGG/Opus pronta para enviar como PTT (push-to-talk) no WhatsApp.

---

## Utils (`src/utils/`)

### `errors.js`
`AppError` com código + status + detalhes. `errorHandler(logger)` middleware Express que loga e devolve JSON `{ error, ... }`.

### `jid.js`
Normaliza JIDs:
- `normalizeForCompare(jid)` — devolve só dígitos, removendo `@c.us`/`@lid`/`@g.us`.
- Helpers para identificar tipo de chat (DM, grupo, etc.).

---

## Scripts CLI (`src/scripts/`)

Scripts auxiliares chamados via `npm run`:

| Script | npm command | O que faz |
|---|---|---|
| `migrate.js` | `npm run migrate` | Aplica migrations pendentes manualmente |
| `hash-password.js` | `npm run hash-password -- '<senha>'` | Gera bcrypt hash |
| `session-reset.js` | `npm run session:reset` | Limpa `data/.wwebjs_auth/` (forçar novo pareamento) |
| `queue-flush.js` | `npm run queue:flush` | Marca todos os `pending` como `error` (limpa fila travada) |
| `export-chat.js` | `npm run export:chat` | Export histórico de um chat para JSON |
| `vacuum.js` | `npm run vacuum` | `VACUUM` no SQLite (recupera espaço após muito DELETE) |

---

## Helpers de shell (`scripts/`)

Scripts não-Node usados pelo agente e ops:

| Script | O que faz |
|---|---|
| `agent-runner.sh` | Daemon que polla e dispara `claude -p` (ver `05-saga-runner.md`) |
| `bootstrap.sh` | Setup idempotente do ambiente nativo (swap, pacotes, nginx, certbot, PM2) |
| `backup.sh` | Backup do `worker.db` (cp + gzip + retenção) |
| `cloudflare.sh` | Helper API Cloudflare (records, add, del, add-cname) |
| `npm.sh` | Helper Nginx Proxy Manager (proxy hosts via API) |
| `meta-ads.sh` | Helper Meta Graph API (accounts, campaigns, insights, raw) |
| `wapi.sh` | Wrapper da API HTTP do worker (lê `API_TOKEN` do `.env`, faz curl com Bearer) |
| `daily-chase.sh` | Cron de cobrança automática de follow-ups |

---

## Pontos de extensão recomendados

| Quero adicionar | Faço onde |
|---|---|
| Novo tipo de evento webhook | `outbound.emit('seu.evento', payload)` em `client.js` ou outro lugar; consumidores se inscrevem em `webhooks` table com `events='seu.evento'` (ou `*`) |
| Nova rota HTTP | Criar `src/routes/<nome>.js` exportando um Router, e registrar em `server.js` |
| Nova integração externa | Helper script em `scripts/<servico>.sh` para uso pelo agente; ou módulo `src/agent/<servico>.js` se for chamado pelo worker |
| Nova fase de resposta automática | Edita `src/agent/api-reply.js` (modelo, system prompt, histórico) — a infra já está montada |
