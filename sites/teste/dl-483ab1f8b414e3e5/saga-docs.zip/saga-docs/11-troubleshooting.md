# 11 — Troubleshooting (bugs conhecidos e soluções)

> Vai aqui antes de chutar solução. Cada entrada tem: sintoma, causa, fix.

---

## 1. `state=ready` mas `client null`

### Sintoma
- `/status` retorna `state: 'ready'`
- Mas `meNumber: null` e `meName: null`
- Qualquer envio falha (timeout silencioso ou erro genérico)
- Mensagens recebidas chegam, mas respostas do agente não saem

### Causa
Race condition no boot do worker. A máquina de estados em `src/wa/state.js` marca `ready` quando o evento `client.on('ready')` dispara, mas se o init foi interrompido (PM2 restart no meio), pode ficar com cliente referenciado em estado intermediário.

### Diagnóstico
```bash
curl -s http://127.0.0.1:3002/status \
  -H "Authorization: Bearer $(grep ^API_TOKEN /opt/saga/.env | cut -d= -f2)" | jq
# Se "state":"ready" e "meNumber":null → bug confirmado
```

### Fix
```bash
pm2 restart saga
sleep 30
# Recheca /status — meNumber deve estar populado
```

Se persiste após 2-3 restarts:
```bash
pm2 stop saga
pkill -9 -f chromium  # mata zumbis Chrome
sleep 5
pm2 start saga
```

### Prevenção
- O `watchdog.js` detecta inatividade e força reinit. Manter `AUTH_WATCHDOG_MS=120000` (padrão) ou menor se for crítico.
- Após qualquer `pm2 restart`, sempre confirmar `/status` antes de assumir que está OK.

---

## 2. WhatsApp `@lid` migration — "No LID for user"

### Sintoma
- Tentar enviar para um contato @c.us novo retorna erro `No LID for user`
- Mensagem fica em `send_queue` com `status='error'` e mensagem de erro do wweb.js
- Acontece tipicamente com contatos que NUNCA mandaram mensagem antes

### Causa
WhatsApp migrou contatos para identificadores `@lid` (Linked ID). O wweb.js tenta mapear `@c.us` → `@lid` internamente, mas falha para contatos novos.

### Fix
Antes de enviar, resolva o JID:
```bash
/opt/saga/scripts/wapi.sh POST /contacts/check '{"number":"55XXXXXXXXXXX"}'
# Retorna o JID correto
```

Ou, no código, use `client.getNumberId(phone)`:
```javascript
const numberId = await client.getNumberId(phone);
const correctChatId = numberId._serialized;
await client.sendMessage(correctChatId, body);
```

### Prevenção
A função `resolvePhone` em `src/wa/contact-resolver.js` faz isso automaticamente. Se o erro persistir, é porque a primeira interação tem que ser **da pessoa para você**, não o contrário.

---

## 3. wweb.js trava sem aviso

### Sintoma
- `pm2 status` mostra saga `online`, uptime crescendo, mas...
- Mensagens novas não chegam mais ao SQLite
- `/status` continua respondendo `ready` (enganador)
- Logs param sem erro óbvio

### Causa
Puppeteer (Chromium headless) entrou em deadlock interno. Costuma acontecer após:
- Memória do Chromium chegou perto de 800 MB (limite do `max_memory_restart`)
- Refresh inesperado do WhatsApp Web do lado do servidor da Meta
- Crash silencioso de uma página dentro do Chromium

### Diagnóstico
```bash
# Memória do worker
ps aux | grep "node src/index.js" | head -1
# Se RES > 700 MB, perto do limite

# Última mensagem registrada no DB
sqlite3 /opt/saga/data/worker.db \
  "SELECT max(timestamp) FROM messages WHERE direction='in';"
# Se for > 5 min atrás e você sabe que recebeu mensagem, está travado
```

### Fix
```bash
pm2 restart saga
# (PM2 faz isso automaticamente se memória > 800M, mas se travou abaixo disso, manual)
```

### Prevenção
- Watchdog (`src/wa/watchdog.js`) deveria detectar — confirme que está ativo nos logs.
- Reduzir `max_memory_restart` para 600M se a VPS tem pouca RAM.
- **Não chamar wweb.js direto em scripts custom** — sempre use os endpoints HTTP (`/send-message`, `/agent/speak`) que já têm `withTimeout` na queue.

---

## 4. `claude -p` exit=124 (timeout)

### Sintoma
- Logs de `agent-runner.log` mostram:
  ```
  [...] claude -p finished exit=124
  ```
- Toda execução do agente termina em 5 min sem produzir resposta

### Causa
- Modelo lento ou com problema na Anthropic
- `claude -p` entrou em loop pedindo permissão (não deveria com `dontAsk`, mas pode acontecer com tool nova não-listada)
- Tarefa real demanda mais de 5 min

### Diagnóstico
```bash
# Pega último log de execução do agente
tail -200 /opt/saga/logs/agent-runner.log | grep -B2 "exit=124" | tail -50
```

Se ver `Permission required` ou similar, é prompt travado.

### Fix
1. Aumentar timeout do daemon:
   ```bash
   nano /opt/saga/scripts/agent-runner.sh
   # Mudar RUN_TIMEOUT=300 para RUN_TIMEOUT=600
   pm2 restart saga-runner
   ```

2. Adicionar tool faltante em `~/.claude/settings.json` (`permissions.allow`).

3. Verificar status Anthropic: https://status.anthropic.com/

---

## 5. Mensagens duplicadas (mesmo conteúdo)

### Sintoma
- Contato recebe a mesma resposta 2 ou 3 vezes em sequência
- Acontece principalmente quando há sessão interativa rodando enquanto o daemon dispara

### Causa
- Sessão interativa do Claude e `saga-runner` rodaram em paralelo (o `pgrep` só bloqueia outros `claude -p`, não sessões interativas)
- Você (humano) respondeu manualmente enquanto o agente respondia também
- Bug ocasional: o agente chama `/send-message` duas vezes na mesma execução (raro)

### Fix imediato
- Mande retratação/correção pelo contato
- Pelo CLAUDE.md, regra "**nunca mandar a mesma mensagem duas vezes**" — agente checa histórico antes de enviar. Reforce essa memória se estiver falhando.

### Prevenção
- Antes de operar interativamente, considere parar o daemon: `pm2 stop saga-runner`
- Após terminar, religar: `pm2 start saga-runner`

---

## 6. Mensagens não acordando o agente

### Sintoma
- Você (whitelist) manda mensagem, o worker registra em `messages`
- Mas `saga-runner` não detecta — não dispara `claude -p`

### Diagnóstico
```bash
# A mensagem entrou no DB?
sqlite3 /opt/saga/data/worker.db <<'SQL'
SELECT id, contact_phone, body, processed_by_agent, from_me, timestamp
FROM messages
ORDER BY id DESC LIMIT 5;
SQL

# Está com processed_by_agent=0?
# Se sim mas não dispara, problema é no daemon. Se está =1, problema é no insert.
```

```bash
# Daemon está rodando?
pm2 status saga-runner

# Logs recentes do daemon
pm2 logs saga-runner --lines 30
```

### Causas possíveis

| Causa | Como confirmar | Fix |
|---|---|---|
| Worker marcou `processed_by_agent=1` (não-whitelist) | `processed_by_agent` no SELECT | Verificar se seu telefone está em `AGENT_WHITELIST` no `.env` |
| Daemon parado | `pm2 status` | `pm2 start saga-runner` |
| Query do daemon não casou | Inspecionar `agent-runner.log` | Conferir se whitelist no script casa com seu telefone |
| `from_me=1` (você mandou da própria conta) | `from_me` no SELECT | Mande de outra conta WhatsApp |

---

## 7. Queue acumulando muitos `pending`

### Sintoma
```bash
sqlite3 /opt/saga/data/worker.db \
  "SELECT count(*) FROM send_queue WHERE status='pending';"
# Retorna > 50
```

### Causas e fixes

#### a) wweb.js travado (não envia)
Ver bug #3 — restart resolve.

#### b) Rate limit da fila
Worker manda 30 msgs/5min por design (anti-ban). Se você enfileirou 200 mensagens de uma vez, vai levar ~30 min para escoar. Não é bug.

#### c) Erro persistente em uma mensagem
```bash
sqlite3 /opt/saga/data/worker.db \
  "SELECT id, error, retry_count FROM send_queue WHERE status='error' LIMIT 5;"
```
Após `MAX_RETRY=3`, mensagem fica em `error` permanente. Bug do conteúdo (ex.: chat_id inválido). Investigue e remova:
```bash
sqlite3 /opt/saga/data/worker.db \
  "DELETE FROM send_queue WHERE status='error' AND id=<ID>;"
```

#### d) Flush total (último recurso)
```bash
/opt/saga/scripts/wapi.sh POST /admin/queue/flush
```
Marca todos os pending como `error: flushed`. Mensagens são perdidas.

---

## 8. Disco cheio

### Sintoma
- SQLite começa a falhar silenciosamente
- Chromium não consegue criar arquivos temp
- Logs param de gravar

### Diagnóstico
```bash
df -h /
du -sh /opt/saga/data/media/  # mídia recebida acumula
du -sh /opt/saga/logs/        # logs antigos
du -sh /opt/saga/data/.wwebjs_auth/  # cache wweb.js
du -sh /var/log/              # logs de sistema
```

### Fix
```bash
# Limpar mídia antiga (>30 dias)
find /opt/saga/data/media/ -type f -mtime +30 -delete

# Limpar logs antigos do sistema
journalctl --vacuum-time=7d

# pm2-logrotate deveria estar cuidando
pm2 conf

# Limpar npm cache
npm cache clean --force
```

### Prevenção
- Monitor disk via cron diário com alerta:
  ```bash
  if [ $(df / --output=pcent | tail -1 | tr -d '% ') -gt 85 ]; then
    /opt/saga/scripts/wapi.sh POST /messages/private \
      "{\"to\":\"<TELEFONE_ALERTA>\",\"body\":\"Disco em $(df -h / | awk 'NR==2{print $5}')\"}"
  fi
  ```

---

## 9. Auth fail no painel admin

### Sintoma
- Login em `https://<SEU_DOMINIO>/login` falha mesmo com senha certa

### Diagnóstico
```bash
# Conferir hash atual
grep ADMIN_PASSWORD_HASH /opt/saga/.env | head -c 20
# Deve começar com $2a$10$ ou $2b$12$
```

### Fix
Regerar:
```bash
cd /opt/saga
npm run hash-password -- 'sua_senha_aqui'
# Cole a saída em ADMIN_PASSWORD_HASH= no .env
pm2 restart saga
```

Se ainda falha, verifique:
- `JWT_SECRET` setado e com 32+ chars
- Cookie do navegador está sendo aceito (clear cookies, tente novamente)
- HTTPS válido (cookies secure só funcionam em HTTPS)

---

## 10. Webhooks de saída não disparam

### Sintoma
- Outros sistemas inscritos em webhooks do Saga não recebem eventos

### Diagnóstico
```bash
# Listar webhooks
/opt/saga/scripts/wapi.sh GET /webhooks | jq

# Ver últimas tentativas
sqlite3 /opt/saga/data/worker.db <<'SQL'
SELECT id, webhook_id, event_type, status, attempts, last_error, sent_at
FROM webhook_deliveries
ORDER BY id DESC LIMIT 20;
SQL
```

### Causas
- Webhook URL inválida (404, DNS não resolve)
- Token validador não bate
- Endpoint destino offline ou retornando 5xx

### Fix
- Testar URL manual com curl
- Reativar webhook:
  ```bash
  sqlite3 /opt/saga/data/worker.db \
    "UPDATE webhooks SET active=1 WHERE id=<ID>;"
  ```
- Re-tentar deliveries em erro:
  ```bash
  sqlite3 /opt/saga/data/worker.db \
    "UPDATE webhook_deliveries SET status='pending', next_retry_at=datetime('now')
     WHERE status='error' AND id IN (...);"
  ```

---

## 11. SSL Let's Encrypt expirou

### Sintoma
- Browser reclama "certificado expirado"
- `https://<SEU_DOMINIO>` retorna erro de TLS

### Diagnóstico
```bash
sudo certbot certificates
# Mostra data de expiração de cada cert
```

### Fix
```bash
sudo certbot renew
sudo systemctl reload nginx
```

### Prevenção
Renovação automática via cron já é instalada pelo certbot. Verifique:
```bash
sudo systemctl list-timers | grep certbot
# Deveria mostrar timer ativo
```

---

## 12. Memória do agente não está sendo lida

### Sintoma
- Você salvou `feedback_xyz.md` mas o agente não muda comportamento
- Em nova conversa, agente age como se memória não existisse

### Diagnóstico
```bash
# Existe o arquivo?
ls ~/.claude/projects/-opt-saga/memory/ | grep xyz

# Está indexado no MEMORY.md?
grep "xyz" ~/.claude/projects/-opt-saga/memory/MEMORY.md
```

### Fixes possíveis

| Problema | Fix |
|---|---|
| Arquivo não existe | Refazer "salva isso" via DM ou criar à mão |
| Não está em `MEMORY.md` | Adicionar linha no índice: `- [Nome](xyz.md) — hook` |
| Memória está em diretório errado | Confira o cwd onde o agente roda (`/opt/saga` para o daemon, `/root` para sessões em /root) |
| Description vaga | Reescrever description com palavras-chave que o agente reconheceria como relevantes |
| Frontmatter quebrado | Validar YAML (---name/description/type/---) |

### Smoke test
Em nova sessão (`cd /opt/saga && claude`), peça: "lista as memórias que você tem sobre [tópico]". Se a sua aparece, está indexada. Se não, problema de indexação.

---

## 13. Auto-resposta (Fase 2) não está respondendo

### Sintoma
- Mensagem de não-whitelist chega
- API Anthropic deveria responder
- Não responde

### Diagnóstico
```bash
# Pânico ativo?
sqlite3 /opt/saga/data/worker.db \
  "SELECT value FROM app_settings WHERE key='api_replies_panic';"
# 1 = silenciado (default), 0 = liberado

# Token Anthropic configurado?
grep ANTHROPIC_API_KEY /opt/saga/.env | head -c 30
# Deve começar com sk-ant-api03-

# Log de tentativas
sqlite3 /opt/saga/data/worker.db <<'SQL'
SELECT created_at, phone, status, reason, error
FROM api_reply_log
ORDER BY id DESC LIMIT 10;
SQL
```

### Causas comuns

| Causa | Fix |
|---|---|
| Pânico ativo | `POST /admin/api-replies/panic '{"enabled":false}'` |
| Token Anthropic vazio/inválido | Editar `.env`, restart |
| Contato silenciado individualmente | `contact_settings.api_replies_enabled` = 1 para o phone |
| Modelo configurado não existe mais | Trocar para modelo válido |

---

## 14. Pareamento WhatsApp não funciona

### Sintoma
- QR não aparece no painel
- Pairing code retornado é inválido (mensagem "código incorreto" no celular)

### Diagnóstico
```bash
# Estado atual
curl -s http://127.0.0.1:3002/status \
  -H "Authorization: Bearer $TOKEN" | jq

# Logs do worker
pm2 logs saga --lines 50 | grep -i "qr\|pairing\|auth"
```

### Fixes

#### Não está em estado "qr"
```bash
# Reset sessão (libera para novo pareamento)
npm run session:reset
pm2 restart saga
sleep 30
```

#### Pairing code inválido
- Use o número exato no formato E.164 sem `+` (ex.: `55XXXXXXXXXXX`).
- Tem 60s de validade — gere novo se demorou.
- WhatsApp do número pareando precisa estar atualizado (apps muito antigos não suportam pairing code).

#### QR não escaneia
- Tela do navegador no painel admin não está renderizando? Hard refresh (`ctrl+F5`).
- QR expirou — atualizar página.
- Tente alternativamente o pairing code.

---

## 15. Quando nada acima resolve

1. Pare tudo:
   ```bash
   pm2 stop all
   ```
2. Backup imediato:
   ```bash
   /opt/saga/scripts/backup.sh
   cp /opt/saga/.env /tmp/saga.env.backup
   ```
3. Logs gerais:
   ```bash
   tail -200 /opt/saga/logs/err.log > /tmp/saga-err.log
   tail -200 /opt/saga/logs/agent-runner.log > /tmp/saga-runner.log
   journalctl -u nginx --since "1 hour ago" > /tmp/nginx.log
   ```
4. Suba de novo, observe boot completo:
   ```bash
   pm2 start ecosystem.config.js
   pm2 logs saga --lines 100
   ```
5. Documente o que aconteceu (cadência, sintomas, ordem dos eventos) — adicione ao seu `feedback_*.md` se for recorrente. Memória vira sua melhor ferramenta de troubleshooting.
