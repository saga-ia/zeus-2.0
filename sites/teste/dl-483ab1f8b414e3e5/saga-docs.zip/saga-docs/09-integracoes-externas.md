# 09 — Integrações Externas

> Cada integração tem um padrão consistente: token salvo em `app_settings` ou `.env`, helper script em `scripts/`, e o agente decide quando chamar via `CLAUDE.md`.

---

## Anthropic API (Fase 2 — auto-resposta)

**Para quê:** quando alguém de fora da whitelist manda mensagem, a Fase 2 responde automaticamente via API direta da Anthropic (sem passar pelo `claude -p`).

**Onde fica:** `src/agent/api-reply.js`.

**Configuração:**
- Token: `.env` → `ANTHROPIC_API_KEY`
- Modelo: `app_settings.api_reply_model` (padrão: `claude-sonnet-4-6`)
- Max tokens: `app_settings.api_reply_max_tokens` (padrão: 512)
- Histórico: `app_settings.api_reply_history_limit` (padrão: 20 mensagens)
- Debounce: `app_settings.api_reply_debounce_ms` (padrão: 8000ms)
- Botão de pânico: `app_settings.api_replies_panic` (`1`=silencia tudo)

**Controles operacionais:**
```bash
# Ver estado
scripts/wapi.sh GET /admin/api-replies/status

# Pânico ON
scripts/wapi.sh POST /admin/api-replies/panic '{"enabled":true}'

# Silenciar contato específico
scripts/wapi.sh POST /admin/api-replies/contact '{"phone":"55XXXXXXXXXXX","enabled":false,"notes":"motivo"}'

# Mudar modelo
scripts/wapi.sh POST /admin/api-replies/setting '{"key":"api_reply_model","value":"claude-haiku-4-5-20251001"}'
```

**Recomendações:**
- Em produção nova, deixe `api_replies_panic=1` por algumas semanas (até treinar bem o agente principal). Depois libere.
- Modelo Haiku é ~10x mais barato que Sonnet — bom default para volume alto e perguntas simples.
- Sonnet entrega qualidade superior em copy/empatia — bom para casos sensíveis.

---

## Groq Whisper (transcrição de áudio)

**Para quê:** transcrever automaticamente áudios de WhatsApp (`type='ptt'` ou `'audio'`) em texto, antes de o agente responder.

**Onde fica:** `src/audio/transcribe.js`.

**Configuração:**
- Token: `.env` → `GROQ_API_KEY`
- Modelo: `whisper-large-v3` (hardcoded no módulo)
- Endpoint: `https://api.groq.com/openai/v1/audio/transcriptions`

**Como funciona:**
1. Worker recebe áudio, baixa para `data/media/`.
2. Chama Groq com o arquivo OGG/Opus.
3. Salva em `messages.transcription` e `transcription_status`.
4. Marca `processed_by_agent=0` (acorda o agente).
5. Agente lê `transcription` e responde como se fosse texto.

**Custo esperado:** Free tier Groq (até ~100 min/dia). Pago a partir disso. Inputs de até 25 MB por request.

**Falha graceful:** se Groq falhar, `transcription_status='failed'` e o agente avisa o usuário "não consegui ouvir, manda em texto".

---

## Microsoft Edge TTS (síntese de voz)

**Para quê:** o agente responde em **áudio** (não só texto), simulando um humano gravando voice. Disparado via endpoint `/agent/speak`.

**Onde fica:** `src/audio/tts.js` + `src/routes/agent.js`.

**Configuração:**
- `.env` → `TTS_VOICE` (padrão `pt-BR-AntonioNeural`), `TTS_RATE`, `TTS_PITCH`
- Sem custo — Edge TTS é grátis e sem limite prático

**Vozes disponíveis:** centenas. Para PT-BR, recomendados:
- `pt-BR-AntonioNeural` (masculina padrão)
- `pt-BR-FranciscaNeural` (feminina padrão)
- `pt-BR-ThalitaNeural` (feminina, mais quente)

**Como o agente usa:**
```bash
scripts/wapi.sh POST /agent/speak '{"chatId":"<JID>","text":"<texto>"}'
```

**Regras de humanização (no CLAUDE.md):**
- Sem emojis
- Sem markdown
- Sem URLs (substituir por "vou mandar o link")
- Sem siglas literais
- Máximo ~30s (~75 palavras)
- Tom natural

---

## Cloudflare DNS

**Para quê:** o agente cria/edita registros DNS dinamicamente para subir landings, dashboards, novas integrações.

**Onde fica:** `scripts/cloudflare.sh`.

**Configuração:**
- Token: `app_settings.cloudflare_api_token`
- Account ID: `app_settings.cloudflare_account_id`
- Zonas: `app_settings.cloudflare_zones` (JSON, opcional)

**Comandos do helper:**
```bash
# Listar registros de uma zona
scripts/cloudflare.sh records <DOMAIN>

# Criar A record
scripts/cloudflare.sh add <DOMAIN> <SUBDOMAIN> <IP>

# Criar CNAME
scripts/cloudflare.sh add-cname <DOMAIN> <NAME> <TARGET>

# Deletar record
scripts/cloudflare.sh del <DOMAIN> <RECORD_ID>
```

**Padrão de uso:** o agente cria DNS automaticamente quando você pede landing/site/dashboard novo. Depois cria proxy host no NPM (próxima seção) e devolve URL pronta.

---

## Nginx Proxy Manager (NPM, via Docker)

**Para quê:** SSL automático Let's Encrypt + proxy reverso configurado via API. Muito mais ágil que Nginx + Certbot manual.

**Onde fica:** `scripts/npm.sh` (helper) + container Docker `nginx-proxy-manager`.

**Configuração:**
- URL admin: `https://manager.<SEU_DOMINIO>` (ou IP:81 se sem subdomínio)
- Login: salvo em `app_settings.npm_admin_email` / `app_settings.npm_admin_password`
- Token API: gerado dinamicamente pelo helper a partir do login

**Comandos:**
```bash
# Adicionar proxy host estático (HTML em pasta)
scripts/npm.sh add-static <SUBDOMAIN>

# Adicionar proxy host para app Node em porta interna
scripts/npm.sh add-proxy <SUBDOMAIN> <HOST_DESTINO> <PORTA>

# Listar proxy hosts
scripts/npm.sh list

# Deletar
scripts/npm.sh del <SUBDOMAIN>
```

**Setup do NPM via Docker (uma vez):**
```bash
mkdir -p /opt/npm/{data,letsencrypt}
docker run -d \
  --name nginx-proxy-manager \
  --restart unless-stopped \
  -p 80:80 -p 443:443 -p 81:81 \
  -v /opt/npm/data:/data \
  -v /opt/npm/letsencrypt:/etc/letsencrypt \
  jc21/nginx-proxy-manager:latest
```
Acesse `:81`, login default `admin@example.com / changeme`, troque, e use o helper.

---

## Meta Graph API (Facebook + Instagram + Ads)

**Para quê:** o agente puxa métricas de Meta Ads de qualquer conta que você tem acesso (não só uma), gerencia posts IG, monitora comentários.

**Onde fica:** `scripts/meta-ads.sh`.

**Configuração:**
- User Token: `app_settings.jeff_meta_user_token` (extended ~60 dias)
- System Token: `app_settings.jeff_meta_system_token` (não expira, escopo limitado)
- Ad Account IDs: descoberto dinamicamente via `accounts` command

**Comandos do helper:**
```bash
# Lista todas as contas que o token tem acesso
scripts/meta-ads.sh accounts

# Campanhas de uma conta
scripts/meta-ads.sh campaigns <ACCOUNT_ID>

# Insights da conta com date_preset
scripts/meta-ads.sh insights <ACCOUNT_ID> last_7d

# Insights de uma campanha específica
scripts/meta-ads.sh insights-campaign <CAMPAIGN_ID> last_30d

# Adsets de uma campanha
scripts/meta-ads.sh adsets <CAMPAIGN_ID>

# Ads de um adset
scripts/meta-ads.sh ads <ADSET_ID>

# GET cru no Graph API
scripts/meta-ads.sh raw <PATH> "<QUERY>"
```

**Métrica recomendada para Click-to-WhatsApp:** reportar **conversas iniciadas** (`onsite_conversion.messaging_conversation_started_7d`), não cliques. Cliques ajudam só sob pedido específico.

**Mutations (criar/pausar/editar campanhas):** **sempre confirmar com o operador antes de executar**. Helper só faz GET por padrão; mutations exigem `raw` com `method=POST`.

**Validade do User Token:** quando der erro de auth, regerar via Graph API Explorer e atualizar `app_settings.jeff_meta_user_token`.

---

## Instagram Graph API (mchat — comment-to-DM)

**Para quê:** quando alguém comenta uma palavra-chave (ex.: "paradigma") em um post seu do IG, o sistema responde publicamente e manda DM com link.

**Onde fica:** `src/agent/mchat_poller.js` + `mchat_settings` table + `mchat_processed_comments` table.

**Configuração via SQL (direto na tabela):**
```sql
UPDATE mchat_settings SET value='paradigma' WHERE key='keywords';
UPDATE mchat_settings SET value='Acabei de te chamar no direct! 🚀' WHERE key='comment_reply';
UPDATE mchat_settings SET value='Oi! Vi que você comentou X...' WHERE key='dm_message';
UPDATE mchat_settings SET value='1' WHERE key='enabled';
UPDATE mchat_settings SET value='30000' WHERE key='poll_interval_ms';
```

**Token Instagram:** salvo separadamente (formato `IGQVJ...`). Pode ser obtido via Facebook Login com escopo `instagram_basic`, `instagram_content_publish`, `pages_show_list`. Documentação Meta para detalhes.

**Idempotência:** cada comentário processado entra em `mchat_processed_comments` com `comment_id` único — não responde 2x ao mesmo comment.

---

## Google APIs (Drive, Gmail, Calendar, Contacts)

**Para quê:** o agente lê/cria arquivos no Drive, manda email, agenda reuniões, busca contatos.

**Onde fica:** OAuth flow configurado via routes (não totalmente implementado em src/, mas estrutura de tokens existe).

**Configuração:**
- Client ID: `app_settings.google_oauth_client_id`
- Client Secret: `app_settings.google_oauth_client_secret`
- Tokens por usuário: `google_oauth_tokens` table (com refresh_token persistido)

**Escopos recomendados:**
- `https://www.googleapis.com/auth/drive` — Drive completo
- `https://www.googleapis.com/auth/gmail.modify` — leitura/envio Gmail
- `https://www.googleapis.com/auth/calendar` — Calendar
- `https://www.googleapis.com/auth/contacts` — Contacts

**Fluxo OAuth (pendente de implementação se você for adicionar agora):**
1. Endpoint `/auth/google/start` redireciona para tela de consentimento Google
2. Google redireciona para `/auth/google/callback?code=...`
3. Worker troca code por access_token + refresh_token, salva em `google_oauth_tokens`
4. Agente lê o token quando precisa, refresh automático quando expira

**Convenção de pastas no Drive:**
- `/Holding/<Empresa>/<Departamento>/...` — operacional
- `/Holding/Família/...` — pessoal (sigilo)
- Compartilha via Gmail com quem precisar.

---

## Asaas (financeiro)

**Para quê:** o agente lista pagamentos pendentes, cria cobranças PIX, consulta clientes.

**Onde fica:** chamadas curl diretas (sem helper script ainda — pode criar `scripts/asaas.sh` análogo aos outros).

**Configuração:**
- Token: `app_settings.asaas_api_token`
- Endpoint: `https://api.asaas.com/v3/`

**Endpoints úteis:**
- `GET /customers` — clientes
- `GET /payments?status=PENDING` — cobranças pendentes
- `GET /payments?status=OVERDUE` — atrasadas
- `POST /payments` — criar cobrança nova

**Header de auth:**
```bash
curl -s -H "access_token: $TOKEN" https://api.asaas.com/v3/payments?status=PENDING
```

---

## ZapSign (assinatura de contratos)

**Para quê:** quando contrato é assinado via ZapSign, webhook dispara para o Saga, que puxa anexa o documento ao CRM correspondente.

**Onde fica:** rota custom em `src/routes/webhooks.js` (configurar separado) ou via `webhooks` table com endpoint público.

**Configuração:**
- Webhook URL: `https://<SEU_DOMINIO>/zapsign-webhook` (criar rota dedicada)
- Token validador: `app_settings.zapsign_webhook_token`
- Token API ZapSign: `app_settings.zapsign_api_token`

**Fluxo típico:**
1. Cliente assina via link ZapSign
2. ZapSign POST → webhook do Saga
3. Saga valida token, identifica cliente pelo phone do signer
4. Faz anexo no CRM (Asaas/Drive/SQLite local)
5. Notifica equipe

---

## Webhooks de saída (genéricos)

**Para quê:** outros sistemas se inscrevem em eventos do Saga (`message.received`, `message.sent`, `message.ack`, `message.edit`, `status.changed`).

**Configuração:**
```bash
scripts/wapi.sh POST /webhooks '{"url":"https://meu-endpoint.com/wh","events":"*","token":"abc123"}'
```

**Retry:** 5 tentativas com backoff exponencial. Persistido em `webhook_deliveries`.

**Validar assinatura no destino:** compare o header `X-Saga-Token` com o token configurado.

---

## Stack de subir landing/dashboard turnkey

Pipeline padrão para responder pedido "cria uma landing pra X" em ~5 minutos:

```bash
SLUG=lancamento-q2

# 1. HTML em pasta dedicada
mkdir -p /opt/saga-sites/$SLUG
cat > /opt/saga-sites/$SLUG/index.html <<'HTML'
<!doctype html>
<html lang="pt-BR">
<!-- ... HTML premium, mobile-first, paleta limitada ... -->
</html>
HTML

# 2. DNS no Cloudflare
scripts/cloudflare.sh add <SEU_DOMINIO> $SLUG <IP_DA_VPS>

# 3. Proxy host com SSL no NPM
scripts/npm.sh add-static $SLUG

# 4. Aguarda SSL (~30s) e devolve URL
echo "https://$SLUG.<SEU_DOMINIO>"
```

Para apps dinâmicos Node+SQLite:
```bash
# 1. Pasta com código Node, porta dedicada (ex: 3010)
mkdir -p /opt/saga-apps/$SLUG
# (ecosystem.config.js + src/)

# 2. PM2 sobe o app
pm2 start /opt/saga-apps/$SLUG/ecosystem.config.js

# 3. DNS + proxy
scripts/cloudflare.sh add <SEU_DOMINIO> $SLUG <IP_DA_VPS>
scripts/npm.sh add-proxy $SLUG 172.17.0.1 3010
```

---

## Tabela-resumo de credenciais por integração

| Integração | Token onde fica | Helper |
|---|---|---|
| Anthropic API | `.env` | (uso direto via SDK) |
| Groq Whisper | `.env` | (uso direto via fetch) |
| Edge TTS | (sem token) | (uso direto, biblioteca local) |
| Cloudflare | `app_settings` | `scripts/cloudflare.sh` |
| NPM | `app_settings` | `scripts/npm.sh` |
| Meta Ads | `app_settings` | `scripts/meta-ads.sh` |
| Instagram | `app_settings` (`mchat_settings`) | (parte do `mchat_poller.js`) |
| Google | `app_settings` + `google_oauth_tokens` | (OAuth flow custom) |
| Asaas | `app_settings` | (curl direto, criar `scripts/asaas.sh` se quiser) |
| ZapSign | `app_settings` | (webhook handler em `routes/webhooks.js`) |

Padrão geral: integração nova = token em `app_settings` + helper script em `scripts/<nome>.sh` + documentação no `CLAUDE.md` ensinando o agente a usar.
