# 06 — Treinamento do Sistema (como deixar o agente muito inteligente)

> **Este é o capítulo mais importante depois da instalação.** Sem treinamento adequado, o sistema é genérico. Com treinamento certo, o agente vira uma extensão da sua operação.

---

## A premissa central

O Saga não é "configurado uma vez e funciona". O agente fica útil **através de uso continuo + feedback**, não via configuração inicial. Cada conversa que você tem com ele é uma chance de torná-lo mais alinhado.

Pense no agente como um **funcionário novo**:
- No primeiro mês ele faz o básico, erra coisas, precisa correção.
- No segundo mês começa a antecipar pedidos.
- No terceiro mês entende o tom da casa.
- Aos seis meses, é insubstituível.

A diferença é que o "funcionário" aqui aprende **só pelo que você grava em memória**. Se não gravar, ele esquece a cada nova conversa.

---

## Os três canais de treinamento

```
┌──────────────────────────────────────────────────────────────────┐
│  Canal 1 — DM via WhatsApp (whitelist)                           │
│    • Você manda mensagem para o número do Saga                   │
│    • saga-runner aciona claude -p                                │
│    • Agente responde e (se você pedir) salva memórias            │
│    • Use para: instruções operacionais, contatos, regras de tom  │
└──────────────────────────────────────────────────────────────────┘
┌──────────────────────────────────────────────────────────────────┐
│  Canal 2 — Sessão interativa (terminal)                          │
│    • cd /opt/saga && claude                                       │
│    • Você conversa direto com o Claude no terminal                │
│    • Use para: setup, refatoração de código, treino mais profundo│
└──────────────────────────────────────────────────────────────────┘
┌──────────────────────────────────────────────────────────────────┐
│  Canal 3 — Edição manual de memórias                             │
│    • ~/.claude/projects/<dir-encoded>/memory/*.md                 │
│    • Você edita arquivos diretamente em editor de texto           │
│    • Use para: cleanups grandes, revisões, correções em massa    │
└──────────────────────────────────────────────────────────────────┘
```

Os três canais escrevem nos **mesmos arquivos de memória**. O agente lê tudo no boot de cada conversa, indiferente do canal.

---

## O ciclo de aprendizado em 4 passos

### Passo 1 — Use o agente para algo concreto
Não tente "treinar" no abstrato. Peça uma tarefa real:
- "Lista os pagamentos vencidos do Asaas"
- "Cria uma landing simples para o evento X"
- "Cobra o Fulano sobre o documento que ele me deve"

### Passo 2 — Observe a primeira tentativa
- Funcionou? Como? (toma nota mental do que ele fez)
- Errou? Em que ponto?
- Foi mais do que pediu? Foi menos?
- Tom certo?

### Passo 3 — Corrija ou confirme
**Se errou:** mande um corretivo claro:
> "Não, eu não quero que você cobre por DM. Quero que você só me liste e eu cobro pessoalmente. Isso vale pra todos os follow-ups."

**Se acertou de forma não-óbvia:** confirme explicitamente:
> "Perfeito, exatamente esse tom. Continua assim."

### Passo 4 — Salve a memória
**Sempre que ele acerta de forma surpreendente OU sempre que ele erra e você corrige**, peça para salvar:
> "Salva isso como regra"
> "Lembra disso pra próxima"
> "Anota que sempre que..."

O agente vai criar um arquivo `feedback_*.md` (ou `project_*.md`) e adicionar ao `MEMORY.md`.

---

## Tipos de memória (resumo — detalhe técnico no cap. 07)

| Tipo | Quando salvar | Exemplo |
|---|---|---|
| **user** | Algo sobre você (papel, preferências, conhecimento) | "Sou empresário, foco em marketing" |
| **feedback** | Regra de comportamento (correção ou confirmação) | "Não cobra por DM, só lista pra eu cobrar" |
| **project** | Fato sobre o projeto/operação (mudanças, decisões, prazos) | "Lançamento da campanha X em DD/MM" |
| **reference** | Onde achar info externa (links, dashboards, contas) | "CRM do Asaas é em asaas.com/login" |

---

## Padrão de comandos para treinar

Frases-gatilho que o agente reconhece como "salva isso":

| Você fala | O agente faz |
|---|---|
| "lembra disso" | Cria memória apropriada (escolhe o tipo) |
| "salva como regra" | Cria `feedback_*.md` |
| "anota que [fato]" | Cria `project_*.md` |
| "guarda esse contato" | Atualiza memória de contatos / tabela `jeff_team` |
| "esquece isso" | Remove a memória correspondente |
| "atualiza a memória de X" | Edita memória existente |
| "mostra minhas memórias" | Lê e lista o `MEMORY.md` |

Quanto mais consistente você for com essas frases, mais previsível o agente fica.

---

## Treinamento progressivo — primeiras semanas

### Semana 1 — Identidade e tom
1. **Defina o nome do agente.** Ex: "a partir de agora seu nome é ZEUS, salva isso."
2. **Defina o tom.** "Comigo: direto, técnico, sem rodeios. Salva."
3. **Defina o que **não** dizer.** "Nunca termine com 'posso ajudar com mais alguma coisa?'. Salva."
4. **Defina como te chamar.** "Me chame de Jefferson, ou Jeff. Não me chame por outro nome. Salva."

### Semana 2 — Contatos da equipe
5. **Cadastre as pessoas-chave.** Para cada uma:
   ```
   "Salva: <Nome>, telefone <DDD9XXXXXXXX>, papel <papel>, tom <tom>."
   ```
   Isso pode virar tanto memória `project_team_members.md` quanto linha em `jeff_team` (SQL). Idealmente as duas coisas.
6. **Defina a hierarquia.** "Se chegar mensagem da minha esposa <nome>, é prioridade máxima — me avisa em DM imediato. Salva."
7. **Defina autorizações.** "<nome> pode autorizar X, Y, Z em meu nome. <outro> só pode autorizar A. Salva."

### Semana 3 — Regras operacionais
8. **Confidencialidade.** "Tudo que falamos em DM é segredo. Não repassa pra ninguém sem ok meu. Salva."
9. **Aprovações.** "Antes de mandar mensagem pra terceiro, sempre pergunta. Salva."
10. **Antiloops.** "Nunca manda a mesma mensagem duas vezes. Sempre confere histórico. Salva."
11. **Ack longo.** "Se a tarefa demora mais de 20s, me avisa antes com ETA. Salva."

### Semana 4 — Operação específica
12. **Cadastre integrações.** "O Cloudflare é da conta X. Salva como referência."
13. **Cadastre dashboards.** "Meu dashboard Asaas é asaas.com/login. Salva."
14. **Cadastre métricas.** "Em campanhas Click-to-WhatsApp, reporta conversas iniciadas, não cliques. Salva."

### Mês 2+ — Refinamento contínuo
- Cada vez que o agente erra, corrige + salva.
- Cada vez que ele acerta de forma não-óbvia, confirma + salva.
- A cada 2-3 semanas, peça: "lê todas as suas memórias e me diz se tem alguma desatualizada".

---

## O que deixa o agente "muito inteligente"

Quatro fatores em ordem de impacto:

### 1. Quantidade e qualidade das memórias
Mais memórias bem-escritas = mais contexto para o agente operar sem perguntar. Mas memórias vagas ou contraditórias confundem mais do que ajudam. Qualidade > quantidade.

### 2. Hábito de **explicar o porquê** ao salvar
"Salva: sempre cobra por SMS, **porque** descobri que minha equipe não vê WhatsApp na hora do almoço."

O **porquê** vira o `**Why:**` da memória, e permite o agente julgar exceções no futuro. Sem o porquê, ele segue cegamente até bater num caso onde a regra não faz sentido.

### 3. Consistência de identificadores
Se você fala "Jefferson", "Jeff", "eu" para se referir a si mesmo, garante que o agente sabe que são a mesma pessoa. Memória `user_jeff_profile.md` deve listar os apelidos.

Se você cadastra "Marcelo" e depois fala "o Marcelinho", o agente precisa saber. "Marcelo (também chamado Marcelinho) — salva."

### 4. Limpeza periódica
A cada 1-2 meses, peça para o agente revisar memórias antigas:
> "Lê todas as memórias de feedback e me lista as que podem estar desatualizadas. Me pergunta uma a uma."

Memórias contraditórias antigas custam mais do que ausência de memória.

---

## Erros comuns no treinamento

### ❌ Salvar muita coisa de uma vez
Pega um momento calmo. Salva uma coisa. Usa por 1-2 dias. Salva outra. Versus dump de 30 regras numa tarde.

### ❌ Salvar sem porquê
"Salva: nunca usa emoji" — ok, mas se um dia fizer sentido (com cliente jovem, p.ex.), o agente não saberá flexibilizar. Melhor: "Nunca uso emoji em comunicação profissional **porque** acho que diminui autoridade. Salva." Aí ele entende que num contexto de marketing casual com cliente jovem, pode considerar.

### ❌ Frases ambíguas
"Salva: responde rápido" — rápido como? 1 min? 1h? **Especifique:** "Salva: respondo em até 5 minutos para quem tá na whitelist; até 1h para Tier 2."

### ❌ Nunca revisar
Memórias acumuladas viram lixo. Revise.

### ❌ Não testar memórias salvas
Salvou? Em uma próxima conversa, faça uma pergunta que **deveria** ativar a memória. Se ele não comportou de acordo, a memória estava mal-escrita ou não foi indexada no `MEMORY.md`. Conserte.

---

## Como saber se o agente está bem treinado

Sinais de bom treinamento:
- ✅ Você raramente precisa repetir uma instrução já dada
- ✅ O agente antecipa pedidos ("vi que tá perto da hora do café, quer o relatório agora?")
- ✅ Quando erra, o erro é em situação inédita, não em algo já discutido
- ✅ O tom dele "soa" como você
- ✅ Ele faz perguntas estratégicas em vez de operacionais ("vai chamar fulano?" vs "qual o tom?")

Sinais de mau treinamento:
- ❌ Repete a mesma pergunta toda conversa
- ❌ Esquece contatos já cadastrados
- ❌ Tom inconsistente
- ❌ Faz coisa que você já disse para não fazer
- ❌ Memórias contraditórias (você corrige uma coisa em janeiro e ele faz oposto em março)

---

## Treinamento via DM vs via terminal

**DM (WhatsApp):**
- Vantagem: você treina no contexto real de uso. Aprendizado fica próximo do uso.
- Desvantagem: cada interação dispara `claude -p` de 30s-2min. Custa tokens. Bom pra ajustes pontuais.

**Terminal (interativo):**
- Vantagem: rápido, gratuito (em modo subscription), você consegue ler/editar memórias em tempo real.
- Desvantagem: separado do contexto operacional. Memórias salvas no terminal valem para o agente DM, mas você está tunando "no laboratório", não em "produção".

**Recomendação:**
- Use DM para correções pontuais ("salva isso").
- Use terminal para limpezas grandes, revisões, refatoração de memórias, e quando precisar editar código.

---

## Cuidados de privacidade

O sistema de memória é **persistente e legível** em texto puro. Antes de salvar, considere:

- **Telefones de pessoas externas**: ok salvar, são operacionais.
- **Dados sensíveis (CPF, dados bancários, senhas)**: preferível **não** salvar em memória. Use o SQLite com criptografia se for preciso, ou armazene fora.
- **Conversas íntimas/familiares**: o agente já trata como confidencial (regras inquebráveis), mas o conteúdo persiste em log do banco. Revise `messages` table para purge periódico se for crítico.

---

## Próximos passos depois do treino básico

Quando o agente estiver respondendo bem dia-a-dia:
1. **Cap. 07 — Criação de memórias**: domine o sistema de arquivos de memória para edição manual.
2. **Cap. 08 — Skills, hooks, keybindings**: avance para automatizar rotinas (slash commands, hooks de ciclo de vida).
3. **Cap. 09 — Integrações**: conecte mais ferramentas (Drive, Calendar, Asaas, Meta) à medida que o uso pede.
4. **Cap. 10 — Operação diária**: rotina sustentável de manutenção.
