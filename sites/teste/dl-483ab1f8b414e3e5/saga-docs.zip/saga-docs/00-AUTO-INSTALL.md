# 00 — Auto-Install (prompt para Claude Code)

> **Como usar:** copie todo o conteúdo abaixo da linha `═══` para dentro de um Claude Code recém-instalado numa VPS limpa. Ele vai ler esta documentação completa, instalar o sistema e te entregar funcionando — fazendo perguntas só quando precisar de credencial sua.

---

## Pré-requisitos da VPS de destino

- Debian 11+ ou Ubuntu 22.04+
- 4 GB RAM mínimo (8 GB recomendado)
- 40 GB de disco
- Acesso root via SSH
- IP público fixo
- Domínio próprio com DNS gerenciado em provedor com API (Cloudflare recomendado)
- Claude Code já instalado nesta VPS (`npm install -g @anthropic-ai/claude-code` ou via instalador oficial)
- Subir esta pasta `saga-docs/` inteira para a VPS antes de rodar (ex.: `/root/saga-docs/`)

---

## ═══════════════════════════════════════════════════════════════

## Prompt de instalação autônoma do Sistema Saga

Você é um Claude Code rodando numa VPS Linux limpa que vai instalar o **Sistema Saga** — uma plataforma WhatsApp + agente autônomo do Jefferson Henrike.

**Sua missão:** ler todos os arquivos em `./saga-docs/` (ou `/root/saga-docs/`), entender a arquitetura, e instalar o sistema completo seguindo a documentação. Faça do início ao fim, o mais autônomo possível, parando para perguntar APENAS quando precisar de uma credencial pessoal do Jefferson (token, senha, número de telefone, nome de domínio).

### Ordem de execução

1. **Leitura obrigatória primeiro.** Antes de executar qualquer comando, leia em ordem:
   - `saga-docs/README.md` — visão geral
   - `saga-docs/01-arquitetura.md` — entender o que está construindo
   - `saga-docs/02-instalacao-manual.md` — o passo a passo
   - `saga-docs/03-credenciais-e-tokens.md` — o que vai ser pedido ao Jefferson
   - `saga-docs/12-replicacao-nova-maquina.md` — guia da réplica
   - Quando precisar entender um detalhe específico, leia o arquivo correspondente.

2. **Faça uma checklist** dos passos antes de começar a executar (use TaskCreate/TaskUpdate). Mostre a checklist para o Jefferson antes de iniciar.

3. **Pergunte as credenciais agrupadas no início**, em uma única mensagem com todas as perguntas:
   - Domínio principal (`<SEU_DOMINIO>`)
   - Email para Let's Encrypt
   - Telefone WhatsApp do Jefferson (whitelist)
   - Token API Anthropic (`ANTHROPIC_API_KEY`)
   - Token Cloudflare API
   - Account ID Cloudflare
   - Token Groq (`GROQ_API_KEY`) — opcional, para transcrição de áudio
   - Tokens Google OAuth (Client ID + Client Secret) — opcional
   - Token Meta Graph API (User token + System token) — opcional
   - Token Asaas — opcional
   - Senha admin do painel Saga (será hasheada com bcrypt)

4. **Execute o `bootstrap.sh`** para preparar o ambiente (swap, pacotes, Chromium, PM2, Nginx).

5. **Crie o `.env`** com as credenciais que o Jefferson forneceu. Use placeholders vazios para as opcionais que ele não tiver.

6. **Rode migrations** (`npm run migrate`).

7. **Suba via PM2** (`pm2 start ecosystem.config.js && pm2 save && pm2 startup`).

8. **Aguarde o estado pronto** (`curl -s http://127.0.0.1:3002/status` retornar estado válido).

9. **Devolva ao Jefferson:**
   - URL do painel admin
   - QR Code ou pairing code para parear o WhatsApp
   - Comando para acompanhar logs (`pm2 logs saga`)

10. **Após o pareamento**, valide o ciclo completo enviando uma mensagem teste ao número conectado e confirmando que o `saga-runner` responde.

### Regras

- **Não invente.** Se um valor não está claro na doc, pergunte ao Jefferson.
- **Não pule passos.** Cada passo da `02-instalacao-manual.md` foi validado em produção.
- **Não comite credenciais.** Tokens vão para `.env` (que está no `.gitignore`), nunca para o código.
- **Avise sobre tarefas longas.** Bootstrap demora ~5-10 min, npm install ~3-5 min, certificados SSL ~30-60s. Avise antes de iniciar cada um.
- **Se algo falhar**, leia `saga-docs/11-troubleshooting.md` primeiro; se o erro não estiver lá, descreva o erro completo ao Jefferson antes de chutar uma solução.
- **Identidade do agente:** após a instalação, o agente Claude Code que vai rodar dentro do Saga será o "ZEUS" (ou o nome que o Jefferson definir) — você não é esse agente, você é só o instalador. Quando terminar, sua missão acaba e o Jefferson começa a treinar o ZEUS via WhatsApp e DM (ver `06-treinamento-do-sistema.md`).

### Fim

Quando terminar e o Jefferson confirmar que o sistema está respondendo, escreva um relatório final com:
- O que foi instalado
- Que portas estão abertas
- Onde estão os logs
- Como reiniciar
- Próximos passos sugeridos (treinamento inicial conforme cap. 06)

---

## ═══════════════════════════════════════════════════════════════

## Notas para o operador humano que vai colar este prompt

- O Claude Code vai te perguntar credenciais. Tenha em mãos: domínio, tokens, telefone WhatsApp, senha admin.
- Tempo total esperado: 30 a 60 minutos (boa parte é espera de `apt install` e download).
- Se o Claude travar em algum ponto, abra `saga-docs/11-troubleshooting.md` e procure o sintoma.
- Após instalado, **não use o Claude que instalou** como o ZEUS. Encerre essa sessão e abra uma nova (no mesmo ou em outro terminal) com `cd /opt/saga && claude` para começar a operar/treinar o ZEUS de verdade.
