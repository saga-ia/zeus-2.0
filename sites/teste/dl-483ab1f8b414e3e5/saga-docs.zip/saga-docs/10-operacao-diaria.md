# 10 — Operação Diária (runbook)

> Tudo que você precisa para manter o Saga vivo e saudável dia-a-dia.

---

## Comandos do dia-a-dia

### Status geral
```bash
# PM2 (os dois processos)
pm2 status

# Esperado: saga e saga-runner com status "online" e uptime crescendo
```

### Status WhatsApp
```bash
curl -s http://127.0.0.1:3002/status \
  -H "Authorization: Bearer $(grep ^API_TOKEN /opt/saga/.env | cut -d= -f2)" | jq

# Sinais saudáveis:
#   "state": "ready"
#   "meNumber": "<TELEFONE_DO_NUMERO_CONECTADO>"
#   "meName": "<NOME_DO_PERFIL>"
```

### Stats do worker
```bash
/opt/saga/scripts/wapi.sh GET /admin/stats | jq

# Exibe: total de mensagens, fila de envio, contagem por tipo, etc.
```

### Logs em tempo real
```bash
# Worker (saga)
pm2 logs saga --lines 50

# Daemon do agente
pm2 logs saga-runner --lines 50

# Ou direto dos arquivos
tail -f /opt/saga/logs/out.log
tail -f /opt/saga/logs/agent-runner.log
```

### Health check (sem auth)
```bash
curl -s http://127.0.0.1:3002/health | jq
# {"status":"ok"}
```

---

## Reiniciar (com cuidado)

```bash
# Reiniciar só o worker (sessão WhatsApp continua, queue persiste)
pm2 restart saga

# Reiniciar só o daemon do agente
pm2 restart saga-runner

# Reiniciar tudo
pm2 restart all
```

**Importante:** após `pm2 restart saga`, aguarde **30 segundos** e cheque `/status` antes de assumir que está pronto. Há o bug `state=ready com client null` (ver `11-troubleshooting.md`).

**Quando reiniciar:**
- Mudou `.env` → restart obrigatório
- Mudou código em `src/` → restart obrigatório
- Mudou `app_settings` (DB) → **não precisa** restart (lido sob demanda)
- Mudou `CLAUDE.md` ou memórias → não precisa restart (Claude Code lê no boot da próxima sessão `claude -p`)

---

## Pareamento e sessão WhatsApp

### Sessão expirou (logout forçado pelo WhatsApp)
Sintoma: `state=disconnected` ou `auth_failure` repetido.

```bash
# Limpa sessão antiga
npm run session:reset

# Restart
pm2 restart saga

# Pega QR ou pairing code
/opt/saga/scripts/wapi.sh GET "/qr?phone=<SEU_TELEFONE>" | jq

# Cole o pairingCode no WhatsApp (configurações → aparelhos conectados)
```

### Forçar reinit do cliente (sem logout)
```bash
/opt/saga/scripts/wapi.sh POST /session/restart
```
Útil quando o cliente parece travado mas não desconectou.

### Logout limpo (gerar novo QR)
```bash
/opt/saga/scripts/wapi.sh POST /session/logout
```

### Marcar conversa como lida
```bash
/opt/saga/scripts/wapi.sh POST /session/read '{"chatId":"<JID>"}'
```

---

## Send Queue (fila anti-ban)

### Ver fila
```bash
/opt/saga/scripts/wapi.sh GET /admin/queue | jq
```

### Ver pendentes/em-erro direto no SQLite
```bash
sqlite3 /opt/saga/data/worker.db <<'SQL'
SELECT id, chat_id, kind, status, retry_count, error, created_at
FROM send_queue
WHERE status IN ('pending', 'sending', 'error')
ORDER BY id DESC
LIMIT 20;
SQL
```

### Limpar fila travada (último recurso)
```bash
/opt/saga/scripts/wapi.sh POST /admin/queue/flush
# Marca tudo que está pending como 'error: flushed'
```

**Quando flushar:** se há centenas de pending acumulados que não deveriam ir mais. Cuidado: você está descartando mensagens que iriam ser enviadas.

---

## Fase 2 (auto-resposta para não-whitelist)

### Estado atual
```bash
/opt/saga/scripts/wapi.sh GET /admin/api-replies/status | jq
```

### Ver últimas auto-respostas
```bash
/opt/saga/scripts/wapi.sh GET "/admin/api-replies/log?limit=20" | jq
```

### Pânico ON (silencia tudo)
```bash
/opt/saga/scripts/wapi.sh POST /admin/api-replies/panic '{"enabled":true}'
```

### Pânico OFF (libera)
```bash
/opt/saga/scripts/wapi.sh POST /admin/api-replies/panic '{"enabled":false}'
```

### Silenciar contato específico
```bash
/opt/saga/scripts/wapi.sh POST /admin/api-replies/contact \
  '{"phone":"55XXXXXXXXXXX","enabled":false,"notes":"motivo"}'
```

### Religar contato silenciado
```bash
/opt/saga/scripts/wapi.sh POST /admin/api-replies/contact \
  '{"phone":"55XXXXXXXXXXX","enabled":true}'
```

### Trocar modelo
```bash
/opt/saga/scripts/wapi.sh POST /admin/api-replies/setting \
  '{"key":"api_reply_model","value":"claude-haiku-4-5-20251001"}'
```

---

## Backup

### Manual
```bash
/opt/saga/scripts/backup.sh
# Gera /opt/saga/data/backups/worker-YYYY-MM-DD.db.gz
```

### Automático (cron)
```bash
crontab -e
# Adicione:
0 3 * * * /opt/saga/scripts/backup.sh >> /opt/saga/logs/backup.log 2>&1
```

### Restore
```bash
# Para o worker (libera o lock no DB)
pm2 stop saga

# Restaura
gunzip -c /opt/saga/data/backups/worker-YYYY-MM-DD.db.gz > /opt/saga/data/worker.db

# Sobe
pm2 start saga
```

### Backup off-site
Recomendado: subir o `.gz` diariamente para Drive/S3/outra VPS.
```bash
# Exemplo com rclone
rclone copy /opt/saga/data/backups/ remote:saga-backups/ --include "*.gz"
```

---

## Monitoramento e métricas

### Mensagens recebidas hoje
```bash
sqlite3 /opt/saga/data/worker.db \
  "SELECT count(*) FROM messages
   WHERE direction='in' AND date(timestamp)=date('now');"
```

### Top contatos por volume nas últimas 24h
```bash
sqlite3 /opt/saga/data/worker.db <<'SQL'
SELECT contact_phone, count(*) as n
FROM messages
WHERE direction='in' AND datetime(timestamp) > datetime('now','-1 day')
GROUP BY contact_phone
ORDER BY n DESC
LIMIT 20;
SQL
```

### Quantos disparos do `saga-runner` hoje
```bash
grep "spawning claude -p" /opt/saga/logs/agent-runner.log \
  | awk -v today="$(date -u +%F)" '$0 ~ today' | wc -l
```

### Quantas auto-respostas (Fase 2) hoje
```bash
sqlite3 /opt/saga/data/worker.db \
  "SELECT count(*) FROM api_reply_log
   WHERE date(created_at)=date('now');"
```

### Tamanho do DB
```bash
ls -lh /opt/saga/data/worker.db
```

### Crescimento de logs
```bash
du -sh /opt/saga/logs/
```

---

## Manutenção semanal (recomendado)

1. **Conferir backups** estão sendo gerados (`ls -lt /opt/saga/data/backups/ | head`).
2. **Verificar memórias** acumuladas (`ls ~/.claude/projects/-opt-saga/memory/ | wc -l`) — se passou de 100, considere revisão.
3. **Conferir logs de erro:**
   ```bash
   grep -i "error\|fatal" /opt/saga/logs/err.log | tail -20
   ```
4. **Atualizar dependências de segurança:**
   ```bash
   cd /opt/saga
   npm audit
   # Aplicar fixes não-breaking se aparecer
   ```
5. **Renovação Let's Encrypt:** está automática, mas confira:
   ```bash
   sudo certbot renew --dry-run
   ```

---

## Manutenção mensal (recomendado)

1. **Vacuum SQLite** (recupera espaço após DELETE/UPDATE intensivo):
   ```bash
   pm2 stop saga
   cd /opt/saga
   npm run vacuum
   pm2 start saga
   ```
2. **Revisar `app_settings`:**
   ```bash
   sqlite3 /opt/saga/data/worker.db "SELECT key, value FROM app_settings;"
   ```
   Procure tokens vencidos, configs obsoletas.
3. **Rotacionar tokens críticos** (anuais ou semestrais — `API_TOKEN`, `JWT_SECRET`).
4. **Revisar logs antigos** — `pm2-logrotate` deveria estar cuidando, mas confirme:
   ```bash
   pm2 conf
   ```
5. **Testar restore de backup** (uma vez por trimestre, no mínimo):
   - Pegue um backup recente
   - Restaure em VPS de teste
   - Confirme que sobe limpo

---

## Quando algo estranho acontecer

1. **Verifica primeiro:** `pm2 status`, `/status`, `/health`. 80% dos problemas são óbvios aqui.
2. **Logs:** `pm2 logs saga` e `pm2 logs saga-runner`. Procure stacktrace ou "ERROR".
3. **Disk:** `df -h /`. Disco cheio causa silenciosamente bug em SQLite, Chromium, logs.
4. **RAM:** `free -h`. Chromium pode vazar — `max_memory_restart: '800M'` no PM2 mata e reinicia, mas se ficar reiniciando direto, é leak grave.
5. **Procura no `11-troubleshooting.md`** o sintoma específico.
6. **Não chute fix.** Diagnostique, depois trate.

---

## Cron jobs típicos

```cron
# Backup diário às 3h UTC
0 3 * * * /opt/saga/scripts/backup.sh >> /opt/saga/logs/backup.log 2>&1

# Cobrança de follow-ups às 12h UTC (9h BRT)
0 12 * * * /opt/saga/scripts/daily-chase.sh >> /opt/saga/logs/daily-chase.log 2>&1

# Vacuum mensal no dia 1 às 4h UTC
0 4 1 * * pm2 stop saga && cd /opt/saga && npm run vacuum && pm2 start saga
```

Ver com `crontab -l`.

---

## Segurança operacional

### Firewall (UFW)
```bash
sudo ufw status verbose
# Esperado: 22 (SSH), 80, 443 abertas. Bloqueia tudo o resto.
```

Se não está configurado:
```bash
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
```

### Fail2ban
```bash
sudo fail2ban-client status
# Lista jails ativas

# Banir manualmente um IP suspeito
sudo fail2ban-client set saga banip <IP>
```

### Brute-force no `/auth`
Logs do worker mostrarão tentativas em `api_logs`:
```bash
sqlite3 /opt/saga/data/worker.db \
  "SELECT ip, count(*) as n FROM api_logs
   WHERE path='/auth/login' AND status_code != 200
     AND datetime(created_at) > datetime('now','-1 hour')
   GROUP BY ip ORDER BY n DESC;"
```

Bloqueie via fail2ban se detectar pattern suspeito.

---

## Atalhos úteis (sugestão)

Adicione ao `~/.bashrc` da VPS:

```bash
# Atalhos Saga
alias saga-status='pm2 status saga saga-runner'
alias saga-logs='pm2 logs saga --lines 50'
alias saga-runner-logs='pm2 logs saga-runner --lines 50'
alias saga-restart='pm2 restart saga'
alias saga-status-wpp='curl -s http://127.0.0.1:3002/status -H "Authorization: Bearer $(grep ^API_TOKEN /opt/saga/.env | cut -d= -f2)" | jq'
alias saga-db='sqlite3 /opt/saga/data/worker.db'
```

```bash
source ~/.bashrc
saga-status   # agora funciona
```
