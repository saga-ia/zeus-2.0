# 03 — Credenciais e Tokens

> Todas as credenciais ficam no arquivo `.env` (com `chmod 600`) ou no SQLite (`app_settings` para tokens dinâmicos). **Nunca** comite o `.env`.

---

## Tabela-resumo

| Token / Credencial | Obrigatório? | Onde fica | Como obter |
|---|---|---|---|
| `API_TOKEN` | **Sim** | `.env` | Gerar local |
| `JWT_SECRET` | **Sim** | `.env` | Gerar local |
| `ADMIN_PASSWORD_HASH` | **Sim** | `.env` | Gerar local (bcrypt) |
| `ANTHROPIC_API_KEY` | **Sim** (para Fase 2 e auto-resposta) | `.env` | Console Anthropic |
| `GROQ_API_KEY` | Recomendado | `.env` | Console Groq |
| Cloudflare API Token | Recomendado | `app_settings` | Dashboard Cloudflare |
| Google OAuth Client | Opcional | `app_settings` + DB | Google Cloud Console |
| Meta User Token (Graph API) | Opcional | `app_settings` | Graph API Explorer |
| Meta System Token | Opcional | `app_settings` | Business Manager |
| Asaas API Token | Opcional | `app_settings` | Conta Asaas |
| ElevenLabs (TTS fallback) | Opcional | `.env` | Conta ElevenLabs |

---

## 1. `API_TOKEN`

**Para que serve:** autenticação Bearer da API HTTP do worker. Todo `wapi.sh` lê este token.

**Como gerar:**
```bash
openssl rand -hex 32
```

**Onde colar:** `.env` → linha `API_TOKEN=...`

**Restrições:** mínimo 32 caracteres (validado em `src/config.js`).

---

## 2. `JWT_SECRET`

**Para que serve:** assinatura dos tokens JWT do painel admin web.

**Como gerar:**
```bash
openssl rand -hex 32
```

**Onde colar:** `.env` → linha `JWT_SECRET=...`

**Restrições:** mínimo 32 caracteres.

---

## 3. `ADMIN_PASSWORD_HASH`

**Para que serve:** senha do usuário `admin` no painel web.

**Como gerar:**
```bash
cd /opt/saga
npm run hash-password -- 'sua_senha_aqui'
# Saída: $2a$10$...
```

**Onde colar:** `.env` → linha `ADMIN_PASSWORD_HASH=$2a$10$...`

**Onde usar depois:** login em `https://<SEU_DOMINIO>/login` com usuário `admin` e a senha em texto puro que você gerou.

---

## 4. `ANTHROPIC_API_KEY`

**Para que serve:** chamadas à API Anthropic para a Fase 2 (auto-resposta a não-whitelist via API direta, sem o `claude -p`).

**Como obter:**
1. Acesse https://console.anthropic.com/
2. Faça login com a conta que vai pagar pelo uso
3. Settings → API Keys → Create Key
4. Copie no formato `sk-ant-api03-...`

**Onde colar:** `.env` → `ANTHROPIC_API_KEY=sk-ant-api03-...`

**Atenção:**
- Esta chave é **separada** da conta Claude Code que o agente usa via `claude -p` (essa autentica via login interativo, não via env).
- Se esta chave estiver vazia, a Fase 2 não funciona, mas o agente principal (via `saga-runner`) continua funcional.

**Custos esperados:** depende do modelo definido em `app_settings.api_reply_model` (padrão `claude-sonnet-4-6`). Para um volume de ~100 mensagens/dia, conta com US$ 5-15/mês.

---

## 5. `GROQ_API_KEY`

**Para que serve:** transcrição de áudios recebidos via Whisper Large v3 (rápido e barato).

**Como obter:**
1. Acesse https://console.groq.com/
2. Login → API Keys → Create API Key
3. Copie no formato `gsk_...`

**Onde colar:** `.env` → `GROQ_API_KEY=gsk_...`

**Atenção:** sem essa chave, áudios chegam com `transcription=null` e `transcription_status=null` — o agente só consegue responder texto.

**Custos:** Groq tem free tier generoso (~100 min/dia). Para uso normal, tende a ficar grátis.

---

## 6. Cloudflare API Token

**Para que serve:** o agente cria/edita registros DNS sozinho (cria subdomínios para landings, dashboards, novas integrações).

**Como obter:**
1. Acesse https://dash.cloudflare.com/profile/api-tokens
2. "Create Token" → "Custom token"
3. Permissions:
   - Zone → DNS → Edit
   - Account → (sua conta) → Read
4. Zone Resources: Include → All zones (ou só a sua)
5. Continue, Create
6. Copie no formato `cfat_...` ou `cfut_...` (não mostrado novamente — guarde imediatamente)

**Onde colar (no banco, não no `.env`):**
```bash
sqlite3 /opt/saga/data/worker.db <<SQL
INSERT OR REPLACE INTO app_settings (key, value, updated_at) VALUES
  ('cloudflare_api_token', 'cfat_xxxxxxxxxxxxxxx', datetime('now')),
  ('cloudflare_account_id', 'xxxxxxxxxxxxxxxxxxxx', datetime('now'));
SQL
```

**Account ID:** você acha em `https://dash.cloudflare.com/` (ID está no canto direito de qualquer página da conta).

**Como o agente usa:** via `scripts/cloudflare.sh`. Ver `09-integracoes-externas.md`.

---

## 7. Google OAuth (Drive, Gmail, Calendar, Contacts)

**Para que serve:** o agente lê/cria arquivos no Drive, manda email pelo Gmail, agenda no Calendar, busca contatos.

**Como obter:**
1. https://console.cloud.google.com/ → criar projeto
2. APIs & Services → Library → habilitar:
   - Google Drive API
   - Gmail API
   - Google Calendar API
   - People API
3. APIs & Services → Credentials → Create Credentials → OAuth client ID
4. Application type: Web application
5. Authorized redirect URIs: `https://<SEU_DOMINIO>/auth/google/callback`
6. Pegar Client ID e Client Secret

**Onde colar:**
```bash
sqlite3 /opt/saga/data/worker.db <<SQL
UPDATE app_settings SET value='<CLIENT_ID>.apps.googleusercontent.com', updated_at=datetime('now')
  WHERE key='google_oauth_client_id';
UPDATE app_settings SET value='<CLIENT_SECRET>', updated_at=datetime('now')
  WHERE key='google_oauth_client_secret';
SQL
```

**Autenticar a conta** (gera refresh_token):
1. Acesse `https://<SEU_DOMINIO>/auth/google/start`
2. Faz login com a conta Google que vai operar o sistema
3. Aceita os escopos (Drive, Gmail, Calendar, Contacts)
4. Token fica salvo em `google_oauth_tokens` (tabela criada na migration 008).

---

## 8. Meta Graph API (Facebook + Instagram + WhatsApp Business + Ads)

**Para que serve:** o agente puxa métricas de campanhas Meta Ads (todas as contas que você tem acesso), publica em Instagram, monitora comentários.

### 8.1 User Access Token (preferencial — cobre múltiplas contas)

**Como obter:**
1. https://developers.facebook.com/tools/explorer/
2. Selecione seu app Meta (ou crie um)
3. Permissões necessárias: `ads_read`, `ads_management`, `business_management`, `instagram_basic`, `instagram_content_publish`, `pages_show_list`, `pages_read_engagement`
4. Generate Access Token
5. **Estender para 60 dias:** "Get Long-Lived Token" (valido por ~60 dias)

**Onde colar:**
```bash
sqlite3 /opt/saga/data/worker.db \
  "INSERT OR REPLACE INTO app_settings (key, value, updated_at) VALUES
    ('jeff_meta_user_token', 'EAAxxxxxxxxxxx', datetime('now'));"
```

### 8.2 System User Token (fallback, não expira)

**Como obter:**
1. Business Manager → Settings → Users → System Users → Create New
2. Generate New Token → app que tenha acesso às contas → escopos como acima
3. Token gerado **não expira**, mas tem acesso só a contas explicitamente atribuídas ao System User

**Onde colar:**
```bash
sqlite3 /opt/saga/data/worker.db \
  "INSERT OR REPLACE INTO app_settings (key, value, updated_at) VALUES
    ('jeff_meta_system_token', 'EAAxxxxxxxxxxx', datetime('now'));"
```

### 8.3 Instagram (para mchat — comment-to-DM)

Tokens Instagram ficam em `mchat_settings` (tabela própria). Detalhes em `09-integracoes-externas.md` na seção mchat.

---

## 9. Asaas API (financeiro)

**Para que serve:** o agente lista pagamentos pendentes/atrasados, gera cobranças PIX, consulta clientes.

**Como obter:**
1. Login em https://www.asaas.com/
2. Configurações → Integrações → API
3. Gerar nova chave de API

**Onde colar:**
```bash
sqlite3 /opt/saga/data/worker.db \
  "INSERT OR REPLACE INTO app_settings (key, value, updated_at) VALUES
    ('asaas_api_token', '$aact_xxxxxxxxxxxxx', datetime('now'));"
```

---

## 10. ElevenLabs (TTS fallback — opcional)

**Para que serve:** alternativa ao Edge TTS para áudios mais naturais. Edge TTS é grátis e default; ElevenLabs entra como fallback se quiser voz clonada.

**Como obter:**
1. https://elevenlabs.io/app/api-keys
2. Generate API Key

**Onde colar:** `.env` → `ELEVENLABS_API_KEY=...` (variável atualmente não-obrigatória, sem campo no `config.js`; se quiser ativar, adicione ao `src/audio/tts.js`).

---

## Como rotacionar tokens

### Tokens em `.env`
1. Atualize a linha no `.env`
2. `pm2 restart saga`

### Tokens em `app_settings`
1. UPDATE direto no SQLite — **não precisa restart** (são lidos sob demanda)

### Token do `wapi.sh` (`API_TOKEN`)
- Rotacionar o `API_TOKEN` invalida todos os scripts que usam `wapi.sh` simultaneamente. Faça em janela combinada.

---

## Checklist de segurança

- [ ] `.env` com `chmod 600`
- [ ] `.env` no `.gitignore`
- [ ] `API_TOKEN` e `JWT_SECRET` com 32+ chars cada, gerados aleatoriamente
- [ ] `ADMIN_PASSWORD_HASH` é bcrypt, não a senha em texto
- [ ] Tokens externos (Anthropic, Cloudflare, etc.) nunca aparecem em logs (`logger.js` faz redação básica de campos sensíveis, mas reveja `pino-pretty` se for tunar)
- [ ] Backup do `worker.db` é encriptado se sair da VPS (`scripts/backup.sh` pode ser estendido com `gpg` ou `age`)
- [ ] Renovação Let's Encrypt automática rodando (`certbot renew --dry-run` deve funcionar)
- [ ] `fail2ban` ativo para bloquear brute-force no `/auth`
- [ ] Firewall (UFW) só com 22, 80, 443 abertas
